import { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import ProductCard from './components/ProductCard';
import LightboxModal from './components/LightboxModal';
import AddProductForm from './components/AddProductForm';
import EscrowInfoSection from './components/EscrowInfoSection';
import { Product, GameNameType } from './types';
import { DEFAULT_PRESEEDS } from './data';
import { 
  Plus, 
  Search, 
  ShieldCheck, 
  Grid, 
  Info, 
  ChevronRight, 
  ArrowRight,
  MessageSquare,
  Sparkles,
  HelpCircle,
  AlertTriangle,
  X
} from 'lucide-react';

export default function App() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedGame, setSelectedGame] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  
  // Lightbox State
  const [activeLightboxProduct, setActiveLightboxProduct] = useState<Product | null>(null);
  const [lightboxIndex, setLightboxIndex] = useState<number>(0);

  // Buy Dialog State (UX confirmation)
  const [activeCheckoutProduct, setActiveCheckoutProduct] = useState<Product | null>(null);

  // Fallback to localStorage if backend is offline or static hosting is used (Vercel / GitHub Pages)
  const loadFromLocalStorage = () => {
    const saved = localStorage.getItem('gamestore_products');
    if (saved) {
      try {
        setProducts(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to parse saved products, falling back to pre-seeds:', e);
        setProducts(DEFAULT_PRESEEDS);
        localStorage.setItem('gamestore_products', JSON.stringify(DEFAULT_PRESEEDS));
      }
    } else {
      setProducts(DEFAULT_PRESEEDS);
      localStorage.setItem('gamestore_products', JSON.stringify(DEFAULT_PRESEEDS));
    }
  };

  // Load products from API with automatic localStorage fallback
  const fetchProducts = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/products');
      if (res.ok) {
        const data = await res.json();
        setProducts(data);
        // Sync/warm cache
        localStorage.setItem('gamestore_products', JSON.stringify(data));
      } else {
        loadFromLocalStorage();
      }
    } catch (err) {
      console.warn('Backend API offline or not found, loading locally:', err);
      loadFromLocalStorage();
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  // Handle adding new product with dual engine (express POST and client localStorage backup)
  const handleAddProduct = async (productData: Omit<Product, 'id' | 'createdAt'>) => {
    const newLocalId = `prod-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const newProductRecord: Product = {
      ...productData,
      id: newLocalId,
      createdAt: new Date().toISOString()
    };

    // Register offline/localStorage first
    const saved = localStorage.getItem('gamestore_products');
    let currentLocalList: Product[] = [];
    if (saved) {
      try {
        currentLocalList = JSON.parse(saved);
      } catch (e) {
        currentLocalList = [...DEFAULT_PRESEEDS];
      }
    } else {
      currentLocalList = [...DEFAULT_PRESEEDS];
    }
    
    const updatedLocalList = [newProductRecord, ...currentLocalList];
    localStorage.setItem('gamestore_products', JSON.stringify(updatedLocalList));

    try {
      const res = await fetch('/api/products', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(productData),
      });

      if (res.ok) {
        // Redraw with server authoritative list if possible
        await fetchProducts();
      } else {
        // Fallback or Vercel static mode
        setProducts(updatedLocalList);
      }
    } catch (err) {
      console.warn('Backend API POST offline or not found, using local storage update:', err);
      setProducts(updatedLocalList);
    }
  };

  // Filter Logic
  const filteredProducts = products.filter((product) => {
    const matchGame = selectedGame === 'All' || product.gameName === selectedGame;
    const matchQuery = product.description.toLowerCase().includes(searchQuery.toLowerCase()) || 
                       product.gameName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchGame && matchQuery;
  });

  // Lightbox Handlers
  const handleOpenLightbox = (product: Product, index: number) => {
    setActiveLightboxProduct(product);
    setLightboxIndex(index);
  };

  const handleCloseLightbox = () => {
    setActiveLightboxProduct(null);
  };

  const handlePrevPhoto = () => {
    if (!activeLightboxProduct) return;
    const total = activeLightboxProduct.photos.length;
    setLightboxIndex((prev) => (prev - 1 + total) % total);
  };

  const handleNextPhoto = () => {
    if (!activeLightboxProduct) return;
    const total = activeLightboxProduct.photos.length;
    setLightboxIndex((prev) => (prev + 1) % total);
  };

  const handleChangeIndex = (index: number) => {
    setLightboxIndex(index);
  };

  // Scroll smoothly to Rekber system section
  const scrollToRules = () => {
    document.getElementById('escrow-rule-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  // Buy Redirect Handler
  const handleRequestCheckout = (product: Product) => {
    setActiveCheckoutProduct(product);
  };

  const handleConfirmPurchase = (product: Product) => {
    const adminNo = '6285872118540';
    const originalPrice = product.price;
    const formattedPrice = new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(originalPrice);

    // Build automated pre-filled text in Indonesia
    const waText = 
      `Halo Admin Lapaku Game, saya ingin membeli akun game berikut melalui Rekber Escrow Aman:\n\n` +
      `*DETAIL PEMBELIAN:*\n` +
      `- *Game:* ${product.gameName}\n` +
      `- *Harga Akun:* ${formattedPrice}\n` +
      `- *No. WA Penjual:* ${product.sellerWa}\n` +
      `- *Detail Akun:* "${product.description.substring(0, 80)}..."\n\n` +
      `Tolong bantu diproses transaksi via Rekber/Escrow agar anti-penipuan. Saya siap melakukan transfer.`;

    const encodedText = encodeURIComponent(waText);
    const waUrl = `https://wa.me/${adminNo}?text=${encodedText}`;
    
    // Redirect out
    window.open(waUrl, '_blank');
    setActiveCheckoutProduct(null);
  };

  const gameTypes: { name: string }[] = [
    { name: 'All' },
    { name: 'Free Fire' },
    { name: 'Mobile Legends' },
    { name: 'CoC' },
    { name: 'Roblox' },
    { name: 'Minecraft' },
    { name: 'Genshin Impact' },
    { name: 'Valorant' },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 selection:bg-emerald-500 selection:text-slate-950 flex flex-col justify-between">
      <div>
        <Navbar onScrollToRules={scrollToRules} />

        {/* Hero Section */}
        <section className="relative overflow-hidden bg-slate-950 py-16 md:py-24 border-b border-slate-900">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-950/20 via-slate-950 to-slate-950 z-0" />
          
          <div className="container mx-auto px-4 md:px-6 relative z-10 text-center space-y-6 max-w-4xl">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-950 border border-emerald-900 rounded-full text-xs font-mono font-bold text-emerald-400">
              <Sparkles className="w-3.5 h-3.5" /> TRANSAKSI AMAN DENGAN REKBER ESCROW RESMI
            </span>
            
            <h2 className="text-4xl md:text-6xl font-display font-extrabold tracking-tight text-white leading-tight">
              Platform Jual Beli Akun Game <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-400">
                100% Aman Terpercaya
              </span>
            </h2>

            <p className="text-slate-400 text-sm md:text-base max-w-2xl mx-auto leading-relaxed">
              Temukan akun Sultan premium Free Fire, Mobile Legends, Genshin Impact, Roblox, dan lainnya. 
              Setiap transaksi dijaga ketat oleh sistem penahanan dana (Escrow/Rekber) Admin untuk anti-ripper & penipuan.
            </p>

            <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
              <a 
                href="#katalog" 
                className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-6 py-3 rounded-xl text-xs md:text-sm tracking-wide transition-all shadow-lg shadow-emerald-500/10 flex items-center gap-1"
              >
                Jelajahi Katalog
                <ArrowRight className="w-4 h-4" />
              </a>

              <button 
                onClick={scrollToRules}
                className="bg-slate-900 hover:bg-slate-800 text-slate-300 font-semibold px-6 py-3 rounded-xl text-xs md:text-sm tracking-wide transition-all border border-slate-800 flex items-center gap-2 cursor-pointer"
              >
                Cara Kerja Anti-Penipuan
              </button>
            </div>
          </div>
        </section>

        {/* Game Listing Section */}
        <main className="container mx-auto px-4 md:px-6 py-12" id="katalog">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10 pb-6 border-b border-slate-900">
            <div>
              <h3 className="text-lg md:text-xl font-display font-bold text-white flex items-center gap-2">
                <Grid className="w-5 h-5 text-emerald-400" />
                Daftar Akun Game Tersedia
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Gunakan filter di bawah untuk mempermudah pencarian game favorit Anda.
              </p>
            </div>

            {/* Live Search Bar */}
            <div className="relative max-w-xs w-full">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500">
                <Search className="w-4 h-4" />
              </span>
              <input
                type="text"
                placeholder="Cari kata kunci..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-950 border border-slate-850 px-3.5 py-2 pl-10 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-emerald-500/80 transition-colors placeholder:text-slate-550"
              />
            </div>
          </div>

          {/* Quick Filters */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-4 mb-8 -mx-4 px-4 scrollbar-none">
            {gameTypes.map((g) => (
              <button
                key={g.name}
                onClick={() => setSelectedGame(g.name)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border flex items-center justify-center cursor-pointer ${
                  selectedGame === g.name
                    ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-lg shadow-emerald-500/10'
                    : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                <span>{g.name}</span>
              </button>
            ))}
          </div>

          {/* Catalog grid */}
          {loading ? (
            <div className="py-20 flex flex-col items-center justify-center gap-4 text-center">
              <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
              <p className="text-slate-400 text-xs font-mono">Memuat database akun game...</p>
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="py-12 px-6 bg-slate-900/40 border border-slate-800 rounded-3xl max-w-3xl mx-auto space-y-8">
              <div className="text-center space-y-3">
                <div className="w-12 h-12 bg-slate-950 border border-slate-800 rounded-2xl flex items-center justify-center mx-auto text-emerald-400">
                  <Grid className="w-6 h-6" />
                </div>
                <h4 className="text-xl font-display font-bold text-white">Belum Ada Akun Game yang Dijual</h4>
                <p className="text-slate-400 text-sm max-w-md mx-auto leading-relaxed">
                  Marketplace baru saja dibuka secara resmi. Jadilah penjual pertama yang mendaftarkan akun game Anda dan dapatkan eksposur langsung ke calon pembeli!
                </p>
              </div>

              {/* Step by step seller onboarding */}
              <div className="border-t border-slate-800/80 pt-6">
                <h5 className="text-xs uppercase font-mono tracking-wider font-bold text-emerald-400 mb-4 text-center">
                  Panduan Menjual Akun Game Anda
                </h5>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-left">
                  <div className="bg-slate-950 border border-slate-800/60 p-4 rounded-xl">
                    <span className="font-mono text-emerald-500 font-extrabold text-sm block mb-1">LANGKAH 1</span>
                    <h6 className="text-xs font-bold text-white mb-1">Unggah Iklan</h6>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Klik tombol tambah di sudut kanan bawah layar Anda untuk membuka formulir input kelengkapan produk.
                    </p>
                  </div>
                  <div className="bg-slate-950 border border-slate-800/60 p-4 rounded-xl">
                    <span className="font-mono text-emerald-500 font-extrabold text-sm block mb-1">LANGKAH 2</span>
                    <h6 className="text-xs font-bold text-white mb-1">Isi Spesifikasi</h6>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Lengkapi nama game, harga target, deskripsi isi bundle akun, nomor WhatsApp Anda, serta unggah tangkapan layar bukti kepemilikan.
                    </p>
                  </div>
                  <div className="bg-slate-950 border border-slate-800/60 p-4 rounded-xl">
                    <span className="font-mono text-emerald-500 font-extrabold text-sm block mb-1">LANGKAH 3</span>
                    <h6 className="text-xs font-bold text-white mb-1">Kirim Ke Admin</h6>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Tekan tombol kirim untuk mendaftarkan akun ke database sistem, serta membuka pesan WhatsApp konfirmasi otomatis kepada Admin.
                    </p>
                  </div>
                </div>
              </div>

              {/* Informative notice on why this is safe */}
              <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl text-center text-xs text-slate-400">
                Sistem pendaftaran ini terproteksi keamanan ganda. Listing akan tayang secara langsung di halaman depan sesaat setelah Admin menyelesaikan pencocokan data akun dengan nomor WhatsApp Anda untuk menjamin integrasi data anti-fraud.
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onOpenLightbox={handleOpenLightbox}
                  onBuy={handleRequestCheckout}
                />
              ))}
            </div>
          )}

          {/* Showcase Section / Educational rules panel */}
          <EscrowInfoSection />
        </main>
      </div>

      {/* Floating Add Product Button */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          onClick={() => setShowAddModal(true)}
          id="add-product-btn"
          className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold w-14 h-14 rounded-full shadow-xl shadow-emerald-500/20 flex items-center justify-center transition-all hover:scale-105 active:scale-95 cursor-pointer ring-4 ring-emerald-500/10"
          title="Tambahkan Iklan Akun Baru"
        >
          <Plus className="w-7 h-7 stroke-[2.5]" />
        </button>
      </div>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-10 text-slate-500 text-xs">
        <div className="container mx-auto px-4 md:px-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center md:text-left">
            <p className="text-slate-350 font-semibold font-mono">
              GAMESTORE LAPAKU OK COPROPRIETORS
            </p>
            <p>Sistem Rekber Resmi terintegrasi WhatsApp Admin: 085872118540</p>
          </div>
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-[10px]">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Escrow & Rekber Protection Active</span>
          </div>
          <p>© 2026 GameStore. Seluruh Hak Cipta Dilindungi.</p>
        </div>
      </footer>

      {/* SHOW LIGHTBOX MODAL */}
      {activeLightboxProduct && (
        <LightboxModal
          product={activeLightboxProduct}
          currentIndex={lightboxIndex}
          onClose={handleCloseLightbox}
          onPrev={handlePrevPhoto}
          onNext={handleNextPhoto}
          onChangeIndex={handleChangeIndex}
        />
      )}

      {/* SHOW ADD PRODUCT FORM MODAL */}
      {showAddModal && (
        <AddProductForm
          onClose={() => setShowAddModal(false)}
          onAddProduct={handleAddProduct}
        />
      )}

      {/* CONFIRM PURCHASE MODAL (EXTRA DESIGN DELIGHT!) */}
      {activeCheckoutProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-850 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl p-6 relative">
            <button 
              onClick={() => setActiveCheckoutProduct(null)} 
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center space-y-4">
              <div className="w-12 h-12 rounded-full bg-emerald-950/50 border border-emerald-900 text-emerald-400 flex items-center justify-center mx-auto">
                <ShieldCheck className="w-6 h-6" />
              </div>
              
              <div className="space-y-1">
                <h4 className="text-lg font-bold text-white">Konfirmasi Transaksi Rekber</h4>
                <p className="text-xs text-slate-400">
                  Semua transaksi diproses aman oleh Rekber Admin untuk mencegah penipuan.
                </p>
              </div>

              {/* Account summary display card */}
              <div className="bg-slate-950 border border-slate-850 rounded-xl p-4 text-left space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Game:</span>
                  <span className="font-bold text-white font-mono uppercase">{activeCheckoutProduct.gameName}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Harga Akun:</span>
                  <span className="font-bold text-emerald-400 font-mono">
                    {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(activeCheckoutProduct.price)}
                  </span>
                </div>
                <div className="border-t border-slate-850 pt-2 text-[11px] text-slate-350 leading-relaxed italic">
                  "{activeCheckoutProduct.description.substring(0, 90)}..."
                </div>
              </div>

              {/* Danger alert explaining physical safety flow */}
              <div className="bg-amber-950/25 border border-amber-900/40 p-3 rounded-xl flex items-start gap-2 text-[10px] text-amber-300 text-left">
                <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
                <span>
                  <strong>Informasi Keamanan:</strong> Jangan melakukan transaksi atau transfer ke penjual langsung di luar grup obrolan resmi Admin! Hanya transfer ke rekening resmi yang diberikan Admin saat obrolan WhatsApp berlangsung.
                </span>
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  onClick={() => setActiveCheckoutProduct(null)}
                  className="flex-1 bg-slate-950 border border-slate-800 hover:bg-slate-900 text-slate-300 py-2.5 rounded-xl text-xs font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  onClick={() => handleConfirmPurchase(activeCheckoutProduct)}
                  className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 py-2.5 rounded-xl text-xs font-bold shadow-lg shadow-emerald-500/10 flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <MessageSquare className="w-3.5 h-3.5 fill-slate-950" />
                  Hubungi Admin WA
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
