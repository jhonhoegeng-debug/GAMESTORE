import { Shield, Sparkles, Flame, Coins } from 'lucide-react';

interface NavbarProps {
  onScrollToRules: () => void;
}

export default function Navbar({ onScrollToRules }: NavbarProps) {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800 bg-slate-950/80 backdrop-blur-md">
      <div className="container mx-auto px-4 md:px-6 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20">
            <Flame className="w-5 h-5 text-slate-950 fill-slate-950" />
          </div>
          <div>
            <h1 className="text-base font-bold font-sans tracking-tight text-white leading-none">
              GAMESTORE
            </h1>
            <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-400 font-bold block mt-0.5">
              Escrow Jaminan Aman
            </span>
          </div>
        </div>

        <nav className="hidden sm:flex items-center gap-6 text-sm">
          <a href="#katalog" className="text-slate-300 hover:text-emerald-400 transition-colors font-medium">
            Katalog Akun
          </a>
          <button 
            onClick={onScrollToRules}
            className="text-slate-300 hover:text-emerald-400 transition-colors font-medium flex items-center gap-1 cursor-pointer"
          >
            <Shield className="w-3.5 h-3.5 text-emerald-400" />
            Cara Kerja Rekber
          </button>
        </nav>

        <div className="flex items-center gap-3">
          <div className="bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 hidden md:flex items-center gap-2">
            <Coins className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-xs text-slate-300 font-mono">
              Sistem Transfer: <strong className="text-white">Rekber Escrow</strong>
            </span>
          </div>

          <button
            onClick={onScrollToRules}
            className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold px-4 py-1.5 rounded-lg text-xs md:text-sm tracking-wide transition-all shadow-lg hover:shadow-emerald-500/10 flex items-center gap-1.5 cursor-pointer"
          >
            <Shield className="w-4 h-4" />
            100% Aman
          </button>
        </div>
      </div>
    </header>
  );
}
