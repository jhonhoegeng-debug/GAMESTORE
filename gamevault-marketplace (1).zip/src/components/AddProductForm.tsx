import { useState, useRef, ChangeEvent, FormEvent } from 'react';
import { X, Upload, Trash2, Plus, Info, Image as ImageIcon, Send } from 'lucide-react';
import { GameNameType, Product } from '../types';

interface AddProductFormProps {
  onClose: () => void;
  onAddProduct: (productData: Omit<Product, 'id' | 'createdAt'>) => Promise<void>;
}

const PRESET_GAME_IMAGES: Record<GameNameType, string[]> = {
  'Free Fire': [
    'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop&q=60',
    'https://images.unsplash.com/photo-1612287230202-1bf1d85d1bdf?w=800&auto=format&fit=crop&q=60'
  ],
  'Mobile Legends': [
    'https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=800&auto=format&fit=crop&q=60',
    'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&auto=format&fit=crop&q=60'
  ],
  'CoC': [
    'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=800&auto=format&fit=crop&q=60',
    'https://images.unsplash.com/photo-1560253023-3ec5d502959f?w=800&auto=format&fit=crop&q=60'
  ],
  'Roblox': [
    'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=800&auto=format&fit=crop&q=60',
    'https://images.unsplash.com/photo-1589241062272-c0a000072dfa?w=800&auto=format&fit=crop&q=60'
  ],
  'Minecraft': [
    'https://images.unsplash.com/photo-1605901309584-818e25960a8f?w=800&auto=format&fit=crop&q=60',
    'https://images.unsplash.com/photo-1627856013091-fed6e4e30025?w=800&auto=format&fit=crop&q=60'
  ],
  'Genshin Impact': [
    'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&auto=format&fit=crop&q=60',
    'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&auto=format&fit=crop&q=60'
  ],
  'Valorant': [
    'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop&q=60',
    'https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=800&auto=format&fit=crop&q=60'
  ]
};

export default function AddProductForm({ onClose, onAddProduct }: AddProductFormProps) {
  const [gameName, setGameName] = useState<GameNameType>('Free Fire');
  const [description, setDescription] = useState('');
  const [priceStr, setPriceStr] = useState('');
  const [sellerWa, setSellerWa] = useState('');
  const [photos, setPhotos] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Trigger preset image injection based on selected game name
  const usePresetImages = () => {
    const presets = PRESET_GAME_IMAGES[gameName] || [];
    setPhotos([...photos, ...presets]);
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    
    setErrorMsg('');
    const filesArray: File[] = Array.from(e.target.files);
    
    filesArray.forEach((file) => {
      if (!file.type.startsWith('image/')) {
        setErrorMsg('Hanya file gambar yang diperbolehkan.');
        return;
      }
      
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setPhotos((prev) => [...prev, event.target!.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });

    // Reset input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleRemovePhoto = (indexToRemove: number) => {
    setPhotos((prev) => prev.filter((_, idx) => idx !== indexToRemove));
  };

  const handleAddCustomUrl = () => {
    const url = prompt('Masukkan URL Gambar Akun Game:');
    if (url && url.trim().startsWith('http')) {
      setPhotos((prev) => [...prev, url.trim()]);
    } else if (url) {
      alert('Masukkan URL yang valid (diawali dengan http/https)');
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    // Validations
    if (photos.length === 0) {
      setErrorMsg('Wajib mengunggah minimal 1 foto akun game.');
      return;
    }

    const price = parseFloat(priceStr.replace(/[^\d]/g, ''));
    if (isNaN(price) || price <= 0) {
      setErrorMsg('Harga harus berupa angka positif.');
      return;
    }

    if (!description.trim() || description.length < 10) {
      setErrorMsg('Deskripsi isi akun wajib minimal 10 karakter.');
      return;
    }

    // WA sanitization (making sure format is robust)
    let waSanitized = sellerWa.trim().replace(/[^\d+]/g, '');
    if (!waSanitized) {
      setErrorMsg('Nomor WhatsApp wajib diisi.');
      return;
    }
    
    // Convert e.g. 085... to 6285...
    if (waSanitized.startsWith('0')) {
      waSanitized = '62' + waSanitized.substring(1);
    } else if (!waSanitized.startsWith('62') && !waSanitized.startsWith('+62')) {
      // standard fallback but make sure it has indonesian dialing prefix
      waSanitized = '62' + waSanitized;
    }

    setLoading(true);

    try {
      // Submit to express backend
      await onAddProduct({
        gameName,
        description,
        price,
        sellerWa: waSanitized,
        photos
      });

      // Redirect out to Admin WhatsApp with nice format requested:
      // TOMBOL "KIRIM KE ADMIN" otomatis membuka link whatsapp ke no admin 085872118540
      const adminNo = '085872118540';
      // Format number to clean numeric wa format: 6285872118540
      const cleanAdminNo = '6285872118540';
      
      const rupiahFormatted = new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0
      }).format(price);

      const waText = `Halo Admin Lapaku Game, saya ingin mendaftarkan produk akun game baru agar diverifikasi dan tayang di Beranda.\n\n` + 
                     `*DETAIL PRODUK:*\n` +
                     `- *Game:* ${gameName}\n` +
                     `- *Harga Jual:* ${rupiahFormatted}\n` +
                     `- *No. WA Penjual:* ${waSanitized}\n` +
                     `- *Rincian Akun:* ${description.substring(0, 150)}${description.length > 150 ? '...' : ''}\n\n` +
                     `Mohon bantu diverifikasi & dikoordinasikan rekber-nya. Terima kasih!`;

      const encodedText = encodeURIComponent(waText);
      const waUrl = `https://wa.me/${cleanAdminNo}?text=${encodedText}`;

      // Open WA Link
      window.open(waUrl, '_blank');

      setLoading(false);
      onClose();
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Gagal menyimpan produk ke server.');
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div 
        className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Form Title */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950/50">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Plus className="w-5 h-5 text-emerald-400" />
              Tambah Akun Game Anda
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Data otomatis dimuat di web & dikonfirmasi ke admin WhatsApp.
            </p>
          </div>
          <button 
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Real Form Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
          {errorMsg && (
            <div className="p-3.5 bg-red-950/40 border border-red-900/50 text-red-300 text-xs rounded-xl font-mono">
              Peringatan: {errorMsg}
            </div>
          )}

          {/* GAME SELECT DROPDOWN */}
          <div className="space-y-1.5">
            <label className="text-xs text-slate-300 font-medium font-sans">
              Pilih Game <span className="text-red-400">*</span>
            </label>
            <select
              value={gameName}
              onChange={(e) => setGameName(e.target.value as GameNameType)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 focus:outline-none focus:border-emerald-500/80 transition-colors font-sans hover:border-slate-700"
            >
              <option value="Free Fire">Free Fire</option>
              <option value="Mobile Legends">Mobile Legends</option>
              <option value="CoC">Clash of Clans (CoC)</option>
              <option value="Roblox">Roblox</option>
              <option value="Minecraft">Minecraft</option>
              <option value="Genshin Impact">Genshin Impact</option>
              <option value="Valorant">Valorant</option>
            </select>
          </div>

          {/* FOTO-FOTO AKUN */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs text-slate-300 font-medium font-sans">
                Foto-Foto Akun Game <span className="text-red-400">*</span>
              </label>
              <span className="text-[10px] text-slate-500">Mendukung multi-upload</span>
            </div>

            {/* Photo Preview Grid */}
            <div className="grid grid-cols-4 gap-2.5">
              {photos.map((photo, idx) => (
                <div key={idx} className="relative aspect-video rounded-xl overflow-hidden border border-slate-800 bg-slate-950 group">
                  <img src={photo} alt="" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => handleRemovePhoto(idx)}
                    className="absolute top-1 right-1 p-1 bg-red-600 hover:bg-red-500 text-white rounded-md transition-colors"
                    title="Hapus Foto"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                  <div className="absolute bottom-0 inset-x-0 bg-slate-950/80 text-[8.5px] font-mono text-center text-slate-400">
                    Foto {idx+1}
                  </div>
                </div>
              ))}

              <div className="flex flex-col gap-1.5 col-span-4 mt-1">
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex-1 bg-slate-950 border border-slate-800 hover:border-emerald-500/50 hover:bg-slate-900 border-dashed py-3.5 px-3 rounded-xl flex flex-col items-center justify-center gap-1.5 cursor-pointer text-slate-400 hover:text-emerald-400 transition-all text-xs"
                  >
                    <Upload className="w-4 h-4 text-emerald-400" />
                    <span>Upload Foto Lokal</span>
                  </button>
                  
                  <button
                    type="button"
                    onClick={handleAddCustomUrl}
                    className="bg-slate-950 border border-slate-800 hover:border-emerald-500/50 py-3.5 px-4 rounded-xl flex flex-col items-center justify-center gap-1.5 cursor-pointer text-slate-400 hover:text-emerald-400 transition-all text-xs"
                  >
                    <Plus className="w-4 h-4" />
                    <span>URL Web</span>
                  </button>

                  <button
                    type="button"
                    onClick={usePresetImages}
                    className="bg-emerald-950/30 border border-emerald-900 hover:bg-emerald-950/50 py-3.5 px-4 rounded-xl flex flex-col items-center justify-center gap-1.5 cursor-pointer text-emerald-400 hover:text-emerald-300 transition-all text-xs"
                    title="Gunakan gambar template berkualitas tinggi jika belum punya file"
                  >
                    <ImageIcon className="w-4 h-4" />
                    <span>Pakai Preset</span>
                  </button>
                </div>
                
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  multiple
                  accept="image/*"
                  className="hidden"
                />
              </div>
            </div>
          </div>

          {/* HARGA */}
          <div className="space-y-1.5">
            <label className="text-xs text-slate-300 font-medium font-sans flex justify-between">
              <span>Harga Jual Akun (Rupiah) <span className="text-red-400">*</span></span>
              <span className="text-[10px] text-amber-400 font-mono">Dikenakan potongan rekber</span>
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-sm">
                Rp
              </span>
              <input
                type="text"
                required
                placeholder="Contoh: 150000"
                value={priceStr}
                onChange={(e) => {
                  const cleaned = e.target.value.replace(/[^\d]/g, '');
                  setPriceStr(cleaned);
                }}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-3.5 py-2.5 text-sm text-white font-mono focus:outline-none focus:border-emerald-500 transition-colors"
              />
            </div>
          </div>

          {/* NOMOR WHATSAPP PENJUAL */}
          <div className="space-y-1.5">
            <label className="text-xs text-slate-300 font-medium font-sans">
              Nomor WhatsApp Penjual Aktif <span className="text-red-400">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="Contoh: 08123456789 atau 6281234567"
              value={sellerWa}
              onChange={(e) => setSellerWa(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white font-mono focus:outline-none focus:border-emerald-500 transition-colors"
            />
          </div>

          {/* DESCRIPTION / DETAIL */}
          <div className="space-y-1.5">
            <label className="text-xs text-slate-300 font-medium font-sans">
              Apa Saja Yang Terdapat Di Akun (Spesifikasi/Bundle) <span className="text-red-400">*</span>
            </label>
            <textarea
              required
              rows={4}
              placeholder="Contoh: BANYAK BUNDLE YG BAGUS BAGUS, Spek Akun Sultan, Level Max, Skin Senjata Lengkap, etc."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500 transition-colors font-sans"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 disabled:opacity-50 text-slate-950 font-bold py-3 px-4 rounded-xl text-xs md:text-sm tracking-wide transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer"
            >
              <Send className="w-4 h-4 text-slate-950" />
              {loading ? 'Menyimpan & Menghubungi Admin...' : 'KIRIM KE ADMIN (Verifikasi WA)'}
            </button>
          </div>
        </form>

        <div className="p-4 bg-slate-950 border-t border-slate-800/80 flex items-start gap-2 text-[10px] text-slate-400 leading-relaxed">
          <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
          <span>
            <strong>Keamanan Ganda:</strong> Ketika data dikirim, data otomatis tersimpan di list agar langsung tampil di beranda, sekaligus membuka chat WhatsApp dengan format template detail akun terstruktur ke nomor Admin <strong>085872118540</strong> untuk dicocokkan.
          </span>
        </div>
      </div>
    </div>
  );
}
