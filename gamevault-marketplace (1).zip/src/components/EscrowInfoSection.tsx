import { useState } from 'react';
import { ShieldAlert, CreditCard, HelpCircle, CheckCircle2, RefreshCw, KeyRound, Database, FileCode } from 'lucide-react';

export default function EscrowInfoSection() {
  const [activeTab, setActiveTab] = useState<'flow' | 'database' | 'fee'>('flow');

  const mysqlSchema = `-- 1. Table untuk Produk list
CREATE TABLE products (
    id VARCHAR(36) PRIMARY KEY,
    game_name VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    price DECIMAL(12, 2) NOT NULL,
    seller_wa VARCHAR(20) NOT NULL,
    status ENUM('available', 'on_hold', 'sold') DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 2. Table untuk Multi-Foto Produk (Relasi One-to-Many)
CREATE TABLE product_photos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id VARCHAR(36) NOT NULL,
    photo_url TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- 3. Table untuk Transaksi Rekber / Escrow
CREATE TABLE transactions (
    id VARCHAR(36) PRIMARY KEY,
    product_id VARCHAR(36) NOT NULL,
    buyer_wa VARCHAR(20) NOT NULL,
    seller_wa VARCHAR(20) NOT NULL,
    original_price DECIMAL(12, 2) NOT NULL,
    admin_fee DECIMAL(12, 2) NOT NULL,
    seller_payout DECIMAL(12, 2) NOT NULL,
    status ENUM('pending_payment', 'secured_by_escrow', 'authorized_release', 'cancelled', 'completed') DEFAULT 'pending_payment',
    payment_proof_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id)
);`;

  const postgresSchema = `-- 1. Table untuk Produk list
CREATE TABLE products (
    id VARCHAR(36) PRIMARY KEY,
    game_name VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    price DECIMAL(12, 2) NOT NULL,
    seller_wa VARCHAR(20) NOT NULL,
    status VARCHAR(20) DEFAULT 'available' CHECK (status IN ('available', 'on_hold', 'sold')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Table untuk Multi-Foto Produk (Relasi One-to-Many)
CREATE TABLE product_photos (
    id SERIAL PRIMARY KEY,
    product_id VARCHAR(36) NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    photo_url TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Table untuk Transaksi Rekber / Escrow
CREATE TABLE transactions (
    id VARCHAR(36) PRIMARY KEY,
    product_id VARCHAR(36) NOT NULL REFERENCES products(id),
    buyer_wa VARCHAR(20) NOT NULL,
    seller_wa VARCHAR(20) NOT NULL,
    original_price DECIMAL(12,2) NOT NULL,
    admin_fee DECIMAL(12,2) NOT NULL,
    seller_payout DECIMAL(12,2) NOT NULL,
    status VARCHAR(30) DEFAULT 'pending_payment' CHECK (status IN ('pending_payment', 'secured_by_escrow', 'authorized_release', 'cancelled', 'completed')),
    payment_proof_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);`;

  return (
    <div id="escrow-rule-section" className="bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 text-slate-100 shadow-xl overflow-hidden my-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-6 border-b border-slate-800">
        <div>
          <span className="text-emerald-400 font-mono tracking-wider text-xs uppercase px-2.5 py-1 rounded-full bg-emerald-950 border border-emerald-900/50">
            Sistem Keamanan & Edukasi Rekber
          </span>
          <h2 className="text-xl md:text-2xl font-sans font-medium tracking-tight text-white mt-2">
            Panduan Rekber Escrow & Struktur Database
          </h2>
        </div>
        
        {/* Tab Controls */}
        <div className="flex p-1 bg-slate-950 rounded-lg border border-slate-800 self-start md:self-center">
          <button
            onClick={() => setActiveTab('flow')}
            className={`px-4 py-1.5 text-xs font-medium rounded-md transition-all flex items-center gap-1.5 ${
              activeTab === 'flow'
                ? 'bg-emerald-500 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            Alur Escrow (Rekber)
          </button>
          <button
            onClick={() => setActiveTab('database')}
            className={`px-4 py-1.5 text-xs font-medium rounded-md transition-all flex items-center gap-1.5 ${
              activeTab === 'database'
                ? 'bg-emerald-500 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            Skema Database
          </button>
          <button
            onClick={() => setActiveTab('fee')}
            className={`px-4 py-1.5 text-xs font-medium rounded-md transition-all flex items-center gap-1.5 ${
              activeTab === 'fee'
                ? 'bg-emerald-500 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5" />
            Perhitungan Biaya
          </button>
        </div>
      </div>

      {activeTab === 'flow' && (
        <div>
          <p className="text-slate-400 text-sm mb-6 leading-relaxed max-w-3xl">
            Sistem escrow (rekening bersama) menjaga keadilan transaksi antara pembeli dan penjual. 
            Uang ditahan sementara oleh pihak Admin Marketplace selaku jembatan terpercaya agar terhindar dari modus kabur atau penyerahan akun bodong.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 relative">
            <div className="absolute top-[28px] left-[5%] right-[5%] h-0.5 bg-slate-800 hidden md:block z-0" />
            
            <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl relative z-10 hover:border-emerald-500/50 transition-colors">
              <div className="w-10 h-10 rounded-lg bg-indigo-950 text-indigo-400 flex items-center justify-center font-mono font-bold text-sm mb-3">
                1
              </div>
              <h4 className="font-semibold text-sm text-white mb-1 flex items-center gap-1">
                Sinyal Keinginan Beli
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Pembeli klik 'Tombol Beli' dan dialihkan ke WhatsApp Admin seharga produk dengan template rincian akun otomatis.
              </p>
            </div>

            <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl relative z-10 hover:border-emerald-500/50 transition-colors">
              <div className="w-10 h-10 rounded-lg bg-amber-950 text-amber-400 flex items-center justify-center font-mono font-bold text-sm mb-3">
                2
              </div>
              <h4 className="font-semibold text-sm text-white mb-1 flex items-center gap-1">
                Amankan Dana (Escrow)
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Pembeli mentransfer dana ke rekening Admin resmi. Admin mematikan status listing di web dan mengonfirmasi dana masuk aman.
              </p>
            </div>

            <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl relative z-10 hover:border-emerald-500/50 transition-colors">
              <div className="w-10 h-10 rounded-lg bg-emerald-950 text-emerald-400 flex items-center justify-center font-mono font-bold text-sm mb-3">
                3
              </div>
              <h4 className="font-semibold text-sm text-white mb-1 flex items-center gap-1">
                Migrasi Akun
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Penjual memberikan kredensial akun kepada Admin. Admin membantu/memantau pembeli mengamankan dan mengubah verifikasi akun.
              </p>
            </div>

            <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl relative z-10 hover:border-emerald-500/50 transition-colors">
              <div className="w-10 h-10 rounded-lg bg-teal-950 text-teal-400 flex items-center justify-center font-mono font-bold text-sm mb-3">
                4
              </div>
              <h4 className="font-semibold text-sm text-white mb-1 flex items-center gap-1">
                Pencairan Dana (Payout)
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Setelah pembeli menyatakan akun aman (Done), Admin mencairkan dana ke Penjual setelah dikurangi biaya admin (fee owner).
              </p>
            </div>
          </div>

          <div className="mt-8 bg-emerald-950/20 border border-emerald-900/50 p-4 rounded-xl flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div className="text-xs text-slate-300">
              <strong className="text-emerald-400 block mb-1">Keunggulan Sistem Escrow Terintegrasi WA:</strong>
              Mereduksi 100% penipuan segitiga (ripper), pemalsuan bukti transfer, atau klaim sepihak. Admin melakukan verifikasi ganda via chat WhatsApp & verifikasi langsung kepemilikan akun (mengganti e-mail/no-telepon pemulihan) sebelum dana dicairkan.
            </div>
          </div>
        </div>
      )}

      {activeTab === 'database' && (
        <div>
          <p className="text-slate-400 text-sm mb-4 leading-relaxed">
            Struktur database di bawah ini dirancang khusus untuk mendukung **Multi-Foto** (banyak foto dalam satu produk/akun game) menggunakan relasi <code className="text-emerald-400 font-mono">One-to-Many</code>.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex flex-col">
              <div className="flex items-center justify-between px-4 py-2 bg-slate-950 border-t border-x border-slate-800 rounded-t-lg">
                <span className="text-xs text-slate-300 font-mono flex items-center gap-1.5">
                  <FileCode className="w-3.5 h-3.5 text-blue-400" />
                  Dialek MySQL
                </span>
                <span className="text-[10px] bg-blue-950 text-blue-400 px-1.5 py-0.5 rounded font-mono">1 to M Photos</span>
              </div>
              <pre className="text-xs bg-slate-950 border border-slate-800 rounded-b-lg p-4 overflow-x-auto text-slate-300 font-mono h-80 focus:outline-none">
                {mysqlSchema}
              </pre>
            </div>

            <div className="flex flex-col">
              <div className="flex items-center justify-between px-4 py-2 bg-slate-950 border-t border-x border-slate-800 rounded-t-lg">
                <span className="text-xs text-slate-300 font-mono flex items-center gap-1.5">
                  <FileCode className="w-3.5 h-3.5 text-emerald-400" />
                  Dialek PostgreSQL
                </span>
                <span className="text-[10px] bg-emerald-950 text-emerald-400 px-1.5 py-0.5 rounded font-mono">Cascade Drop</span>
              </div>
              <pre className="text-xs bg-slate-950 border border-slate-800 rounded-b-lg p-4 overflow-x-auto text-slate-300 font-mono h-80 focus:outline-none">
                {postgresSchema}
              </pre>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'fee' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-4">
            <h4 className="text-lg font-medium text-white mb-2">Simulasi Keuntungan dan Skema Biaya Rekber</h4>
            <p className="text-slate-400 text-sm leading-relaxed">
              Biaya administrasi (fee rekber) dapat dibebankan ke pembeli, penjual, atau dibagi rata. 
              Disarankan menggunakan skema **Fee Owner (Dipotong dari Penjual)** atau **Flat Fee Tambahan (Ditanggung Pembeli)**.
            </p>

            <div className="space-y-3">
              <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm font-semibold text-slate-200">Skema Potongan Penjual (Fee Owner)</span>
                  <span className="text-xs font-mono text-emerald-400">Default (3% - 5%)</span>
                </div>
                <p className="text-xs text-slate-400">
                  Harga yang dipajang adalah bersih atau kotor. Biaya admin dipotong langsung sebelum dana dikirim ke penjual asli.
                </p>
                <div className="mt-2 text-xs bg-indigo-950/30 text-indigo-300 px-2.5 py-1.5 rounded-lg font-mono">
                  Dana yang Diterima Penjual = Harga Tertera - Fee Admin (Min 5.000 atau 5% Harga)
                </div>
              </div>

              <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm font-semibold text-slate-200">Skema Biaya Pembeli (Buyer Charge)</span>
                  <span className="text-xs font-mono text-amber-400">Alternatif</span>
                </div>
                <p className="text-xs text-slate-400">
                  Pembeli membayar harga barang + Biaya Flat Rekber (biasanya Rp5.000,- s/d Rp15.000,- tergantung nominal harga).
                </p>
              </div>
            </div>
          </div>

          <div className="bg-slate-950 border border-slate-800 p-5 rounded-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-1.5 mb-2">
                <KeyRound className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-mono tracking-wider uppercase text-slate-400">Kalkulator Fee</span>
              </div>
              <h5 className="text-sm font-semibold text-white mb-4">Contoh Skenario Akun Rp 150.000</h5>
              
              <ul className="space-y-3.5 text-xs text-slate-300">
                <li className="flex justify-between">
                  <span className="text-slate-400">Harga Jual Akun:</span>
                  <span className="font-mono text-white">Rp 150.000</span>
                </li>
                <li className="flex justify-between pb-2 border-b border-slate-800">
                  <span className="text-slate-400">Admin Fee (5%):</span>
                  <span className="font-mono text-red-400">- Rp 7.500</span>
                </li>
                <li className="flex justify-between pt-1">
                  <span className="text-slate-400 font-semibold text-emerald-400">Iterasi Payout Penjual:</span>
                  <span className="font-mono text-emerald-400 font-bold">Rp 142.500</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-slate-400 font-semibold text-cyan-400">Keuntungan Platform:</span>
                  <span className="font-mono text-cyan-400 font-bold">Rp 7.500</span>
                </li>
              </ul>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-800 text-[10px] text-slate-400 leading-relaxed">
              *Penetapan nominal transfer wajib disertai detail 3 digit kode unik (misal: Rp 150.720) bagi pembeli untuk mempermudah deteksi pembayaran otomatis di sisi Admin.
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
