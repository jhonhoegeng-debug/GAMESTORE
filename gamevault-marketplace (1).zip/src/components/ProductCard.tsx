import { Product } from '../types';
import { MessageSquare, Image as ImageIcon, ShieldCheck, Tag } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onOpenLightbox: (product: Product, index: number) => void;
  onBuy: (product: Product) => void;
}

export default function ProductCard({ product, onOpenLightbox, onBuy }: ProductCardProps) {
  // Helper to format currency to Rupiah style or high-quality clean layout
  const formatRupiah = (num: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(num);
  };

  const getGameBadgeColor = (game: string) => {
    switch (game) {
      case 'Free Fire':
        return 'from-orange-500 to-red-600 border-orange-500/35 text-white';
      case 'Mobile Legends':
        return 'from-blue-600 to-indigo-700 border-blue-500/35 text-white';
      case 'CoC':
        return 'from-amber-600 to-amber-700 border-amber-500/35 text-amber-100';
      case 'Roblox':
        return 'from-slate-600 to-slate-800 border-slate-500/35 text-slate-100';
      case 'Minecraft':
        return 'from-green-600 to-emerald-700 border-green-500/35 text-white';
      case 'Genshin Impact':
        return 'from-purple-600 to-pink-700 border-purple-500/35 text-white';
      case 'Valorant':
        return 'from-rose-600 to-rose-800 border-rose-500/35 text-white';
      default:
        return 'from-slate-600 to-slate-700 border-slate-500/35 text-white';
    }
  };

  const mainPhoto = product.photos[0] || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop&q=60';
  const photoCount = product.photos.length;

  return (
    <article className="group bg-slate-900/40 border border-slate-800 hover:border-slate-700 rounded-2xl overflow-hidden transition-all duration-300 hover:shadow-xl hover:shadow-slate-950/40 flex flex-col h-full">
      {/* Product Image Section */}
      <div className="relative aspect-video w-full overflow-hidden bg-slate-950">
        <img
          src={mainPhoto}
          alt={`Akun ${product.gameName}`}
          referrerPolicy="no-referrer"
          onClick={() => onOpenLightbox(product, 0)}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 cursor-zoom-in"
          onError={(e) => {
            // fallback image if broken link
            e.currentTarget.src = 'https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=800&auto=format&fit=crop';
          }}
        />
        
        {/* Game Name Tag Overlay */}
        <div className="absolute top-3 left-3 flex items-center gap-1.5 shadow-md">
          <span className={`bg-gradient-to-r ${getGameBadgeColor(product.gameName)} px-2.5 py-1 text-[11px] font-mono tracking-wider font-extrabold rounded-lg uppercase border shadow-sm`}>
            {product.gameName}
          </span>
        </div>

        {/* Dynamic Image Count Badge */}
        {photoCount > 1 && (
          <button 
            onClick={() => onOpenLightbox(product, 0)}
            className="absolute bottom-3 right-3 bg-slate-950/80 backdrop-blur-sm border border-slate-800 text-slate-300 text-xs px-2.5 py-1 rounded-lg flex items-center gap-1.5 hover:text-white hover:bg-slate-900 transition-colors cursor-pointer"
          >
            <ImageIcon className="w-3.5 h-3.5 text-emerald-400" />
            <span>{photoCount} Foto</span>
          </button>
        )}
      </div>

      {/* Content Section */}
      <div className="p-5 flex flex-col flex-grow justify-between">
        <div className="space-y-2">
          {/* Headline / Price info */}
          <div className="flex items-baseline justify-between gap-2">
            <span className="text-xl font-bold font-mono text-emerald-400 tracking-tight">
              {formatRupiah(product.price)}
            </span>
            <span className="text-[10px] font-mono text-slate-500 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-emerald-500" /> REKBER ACTIVE
            </span>
          </div>

          {/* Description */}
          <p className="text-slate-300 text-sm leading-relaxed line-clamp-3 min-h-[60px] font-sans">
            {product.description}
          </p>
        </div>

        {/* Footer info & Buy Button */}
        <div className="mt-5 pt-4 border-t border-slate-800/60 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span className="flex items-center gap-1">
              <Tag className="w-3.5 h-3.5" /> Game Account
            </span>
            <span className="font-mono bg-slate-950 border border-slate-800/80 px-2 py-0.5 rounded font-semibold text-[10px] text-emerald-400">
              WA Penjual: {product.sellerWa.substring(0, 4)}***{product.sellerWa.slice(-3)}
            </span>
          </div>

          <button
            onClick={() => onBuy(product)}
            className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold py-2.5 px-4 rounded-xl text-xs md:text-sm tracking-wide transition-all shadow-md shadow-emerald-950/20 active:scale-[0.98] flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <MessageSquare className="w-4 h-4 text-slate-950 fill-slate-950" />
            Hubungi Admin & Beli Akun
          </button>
        </div>
      </div>
    </article>
  );
}
