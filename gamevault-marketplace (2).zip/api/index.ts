import express from 'express';
import { DEFAULT_PRESEEDS } from '../src/data';

const app = express();

app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

// Serverless in-memory helper (will periodically reset, which is standard for serverless databases, 
// and clients can fallback cleanly to localStorage)
let products = [...DEFAULT_PRESEEDS];

app.get('/api/products', (req, res) => {
  res.setHeader('Cache-Control', 's-maxage=1, stale-while-revalidate');
  res.json(products);
});

app.post('/api/products', (req, res) => {
  const { gameName, description, price, sellerWa, photos } = req.body;

  if (!gameName || !description || !price || !sellerWa || !photos || !Array.isArray(photos)) {
    return res.status(400).json({ error: 'Kolom produk tidak lengkap!' });
  }

  const newProduct = {
    id: `prod-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    gameName,
    description,
    price: Number(price),
    sellerWa,
    photos,
    createdAt: new Date().toISOString()
  };

  products.unshift(newProduct);

  res.status(201).json({
    success: true,
    message: 'Sukses mendaftarkan iklan produk akun game!',
    product: newProduct
  });
});

app.get('/api/whatsapp-generator', (req, res) => {
  const { action, sellerNo, game, price, description } = req.query;
  const adminNo = '6285872118540';

  if (action === 'pendaftaran') {
    const text = `Halo Admin Lapaku Game, saya ingin mendaftarkan produk akun game baru agar diverifikasi.\n\n- Game: ${game}\n- Harga: Rp ${price}\n- WA Penjual: ${sellerNo}\n\nMohon diproses untuk tayang di Beranda.`;
    const url = `https://wa.me/${adminNo}?text=${encodeURIComponent(text)}`;
    return res.json({ url });
  } else if (action === 'pembelian') {
    const text = `Halo Admin, saya ingin membeli akun ${game} dengan detail "${description}" seharga Rp ${price}. Tolong proses via Rekber/Escrow agar anti-penipuan.`;
    const url = `https://wa.me/${adminNo}?text=${encodeURIComponent(text)}`;
    return res.json({ url });
  }

  res.status(400).json({ error: 'Action tidak dikenali' });
});

// For local testing of custom routes or when serverless handles it
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', environment: 'vercel-serverless' });
});

export default app;
