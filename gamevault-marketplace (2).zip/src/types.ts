export type GameNameType = 
  | 'Free Fire' 
  | 'Mobile Legends' 
  | 'CoC' 
  | 'Roblox' 
  | 'Minecraft' 
  | 'Genshin Impact'
  | 'Valorant';

export interface Product {
  id: string;
  gameName: GameNameType;
  description: string;
  price: number;
  sellerWa: string;
  photos: string[];
  createdAt: string;
}

export interface EscrowRule {
  title: string;
  description: string;
  details: string;
}
