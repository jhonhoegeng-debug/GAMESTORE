import { Product } from './types';

export const DEFAULT_PRESEEDS: Product[] = [
  {
    id: "prod-ff-1",
    gameName: "Free Fire",
    description: "Akun Free Fire Sultan Tier Grandmaster. Elite Pass Season 4, 5, 8, 12, 20 Aktif. Set Letda Hyper lengkap, Shotgun 2 Terompet (SG M1887 Rapper Underworld), M1014 Apocalyptic, CN Aktif, Akun Pribadi Tangan Pertama.",
    price: 150000,
    sellerWa: "628123456780",
    photos: [
      "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop&q=60",
      "https://images.unsplash.com/photo-1612287230202-1bf1d85d1bdf?w=800&auto=format&fit=crop&q=60",
      "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&auto=format&fit=crop&q=60"
    ],
    createdAt: new Date().toISOString()
  },
  {
    id: "prod-ml-1",
    gameName: "Mobile Legends",
    description: "Sultan Akun MLBB Mythical Glory Premium. Total Hero 124, Skin Collector Granger & Gusion KOF, Skin Legend Saber & Alucard, Winrate total 68.5% aman terkendali, Emblem level Max semua. Siap rekber escrow aman!",
    price: 350000,
    sellerWa: "628998877665",
    photos: [
      "https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=800&auto=format&fit=crop&q=60",
      "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&auto=format&fit=crop&q=60"
    ],
    createdAt: new Date().toISOString()
  },
  {
    id: "prod-val-1",
    gameName: "Valorant",
    description: "Akun Valorant Platinum 3 Bergaransi. Skin Reaver Vandal, Prime Vandal, RGX Butterfly Blade, Sovereign Ghost. Full Agent terbuka, sisa 1200 VP, 85 Radianite Points. Akun Bersih anti-hackback.",
    price: 290000,
    sellerWa: "6281288776632",
    photos: [
      "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop&q=60",
      "https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=800&auto=format&fit=crop&q=60"
    ],
    createdAt: new Date().toISOString()
  },
  {
    id: "prod-roblox-1",
    gameName: "Roblox",
    description: "Akun Roblox Blox Fruits Max Level 2550. Melee Godhuman, Fruit Leopard fully awakened, banyak gamepass, memiliki pedang Tushita, Yama, Shisui lengkap. Item melimpah, tinggal pakai.",
    price: 95000,
    sellerWa: "628554433221",
    photos: [
      "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=800&auto=format&fit=crop&q=60",
      "https://images.unsplash.com/photo-1589241062272-c0a000072dfa?w=800&auto=format&fit=crop&q=60"
    ],
    createdAt: new Date().toISOString()
  },
  {
    id: "prod-genshin-1",
    gameName: "Genshin Impact",
    description: "Genshin Impact AR 57 Server Asia. C2 Raiden Shogun + Elgulfing Lightning, C1 Ayaka + Mistsplitter, Zhongli, Kazuha, Nahida. Stat rapi, artifact dewa, bintang 5 melimpah ruah. No minus, anti-hackback.",
    price: 480000,
    sellerWa: "628112233445",
    photos: [
      "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&auto=format&fit=crop&q=60",
      "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=800&auto=format&fit=crop&q=60"
    ],
    createdAt: new Date().toISOString()
  },
  {
    id: "prod-coc-1",
    gameName: "CoC",
    description: "Town Hall (TH) 14 Semi Max. Hero BK 75, AQ 80, GW 55, RC 25. Defense kokoh, ganti nama murah meriah, akun pribadi tangan pertama jaminan aman 100%.",
    price: 250000,
    sellerWa: "628221144335",
    photos: [
      "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&auto=format&fit=crop&q=60",
      "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=800&auto=format&fit=crop&q=60"
    ],
    createdAt: new Date().toISOString()
  }
];
