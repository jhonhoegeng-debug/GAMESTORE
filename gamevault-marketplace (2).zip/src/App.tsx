import { useState, useEffect, useRef } from 'react';
import Navbar from './components/Navbar';
import ProductCard from './components/ProductCard';
import LightboxModal from './components/LightboxModal';
import AddProductForm from './components/AddProductForm';
import EscrowInfoSection from './components/EscrowInfoSection';
import { Product } from './types';
import { DEFAULT_PRESEEDS } from './data';
import { 
  Plus, 
  ShieldCheck, 
  Grid, 
  Search,
  MessageSquare,
  AlertTriangle,
  Flame,
  X
} from 'lucide-react';

export default function App() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedGame, setSelectedGame] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [currentPage, setCurrentPage] = useState<string>('home');
  
  // Custom Dynamic Locked Banner State (Persisted in localStorage)
  const [heroBanner, setHeroBanner] = useState<string | null>(() => {
    return localStorage.getItem('gamestore_hero_banner') || null;
  });
  const bannerFileRef = useRef<HTMLInputElement>(null);

  // Dynamic Invoices data sync (useful for checkout history)
  const [invoices, setInvoices] = useState<any[]>(() => {
    const saved = localStorage.getItem('gamestore_invoices');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { }
    }
    const initialInvoices = [
      {
        id: 'INV-FF-8821',
        gameName: 'Free Fire',
        price: 150000,
        sellerWa: '628123456780',
        description: 'Akun Free Fire Sultan Tier Grandmaster. Elite Pass S4, S5.',
        status: 'DANA AMAN DI REKBER ADMIN',
        date: '2026-05-28 10:45',
        codeUnik: 742,
      },
      {
        id: 'INV-ML-5521',
        gameName: 'Mobile Legends',
        price: 350000,
        sellerWa: '628998877665',
        description: 'Sultan Akun MLBB Mythical Glory Premium. Total Hero 124, Collector Granger & KOF.',
        status: 'MIGRASI DATA SEDANG DIALIRKAN',
        date: '2026-05-28 12:15',
        codeUnik: 120,
      }
    ];
    localStorage.setItem('gamestore_invoices', JSON.stringify(initialInvoices));
    return initialInvoices;
  });
  
  // Lightbox State
  const [activeLightboxProduct, setActiveLightboxProduct] = useState<Product | null>(null);
  const [lightboxIndex, setLightboxIndex] = useState<number>(0);

  // Buy Dialog State (UX confirmation)
  const [activeCheckoutProduct, setActiveCheckoutProduct] = useState<Product | null>(null);

  const loadFromLocalStorage = () => {
    const saved = localStorage.getItem('gamestore_products');
    if (saved) {
      try {
        setProducts(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to parse saved products, falling back to pre-seeds:', e);
        setProducts(DEFAULT_PRESEEDS);
        localStorage.setItem('gamestore_products', JSON.stringify(DEFAULT_PRESEEDS));
      }
    } else {
      setProducts(DEFAULT_PRESEEDS);
      localStorage.setItem('gamestore_products', JSON.stringify(DEFAULT_PRESEEDS));
    }
  };

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/products');
      if (res.ok) {
        const data = await res.json();
        setProducts(data);
        localStorage.setItem('gamestore_products', JSON.stringify(data));
      } else {
        loadFromLocalStorage();
      }
    } catch (err) {
      console.warn('Backend API offline or not found, loading locally:', err);
      loadFromLocalStorage();
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const handleAddProduct = async (productData: Omit<Product, 'id' | 'createdAt'>) => {
    const newLocalId = `prod-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const newProductRecord: Product = {
      ...productData,
      id: newLocalId,
      createdAt: new Date().toISOString()
    };

    const saved = localStorage.getItem('gamestore_products');
    let currentLocalList: Product[] = [];
    if (saved) {
      try {
        currentLocalList = JSON.parse(saved);
      } catch (e) {
        currentLocalList = [...DEFAULT_PRESEEDS];
      }
    } else {
      currentLocalList = [...DEFAULT_PRESEEDS];
    }
    
    const updatedLocalList = [newProductRecord, ...currentLocalList];
    localStorage.setItem('gamestore_products', JSON.stringify(updatedLocalList));

    try {
      const res = await fetch('/api/products', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(productData),
      });

      if (res.ok) {
        await fetchProducts();
      } else {
        setProducts(updatedLocalList);
      }
    } catch (err) {
      console.warn('Backend API POST offline or not found, using local storage update:', err);
      setProducts(updatedLocalList);
    }
  };

  const filteredProducts = products.filter((product) => {
    const matchGame = selectedGame === 'All' || product.gameName === selectedGame;
    const matchQuery = product.description.toLowerCase().includes(searchQuery.toLowerCase()) || 
                       product.gameName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchGame && matchQuery;
  });

  const handleOpenLightbox = (product: Product, index: number) => {
    setActiveLightboxProduct(product);
    setLightboxIndex(index);
  };

  const handleCloseLightbox = () => {
    setActiveLightboxProduct(null);
  };

  const handlePrevPhoto = () => {
    if (!activeLightboxProduct) return;
    const total = activeLightboxProduct.photos.length;
    setLightboxIndex((prev) => (prev - 1 + total) % total);
  };

  const handleNextPhoto = () => {
    if (!activeLightboxProduct) return;
    const total = activeLightboxProduct.photos.length;
    setLightboxIndex((prev) => (prev + 1) % total);
  };

  const handleChangeIndex = (index: number) => {
    setLightboxIndex(index);
  };

  const handleBannerUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (heroBanner) return; // Locked: banner can only be uploaded once.

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      setHeroBanner(base64String);
      localStorage.setItem('gamestore_hero_banner', base64String);
    };
    reader.readAsDataURL(file);
  };

  const handleResetBanner = () => {
    setHeroBanner(null);
    localStorage.removeItem('gamestore_hero_banner');
  };

  const handleRequestCheckout = (product: Product) => {
    setActiveCheckoutProduct(product);
  };

  const handleConfirmPurchase = (product: Product) => {
    const adminNo = '6285872118540';
    const originalPrice = product.price;
    const formattedPrice = new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(originalPrice);

    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const codeUnik = Math.floor(100 + Math.random() * 899);
    const invoiceId = `INV-${product.gameName.substring(0, 3).toUpperCase().replace(/\s/g, '')}-${randomSuffix}`;
    
    const newInvoice = {
      id: invoiceId,
      gameName: product.gameName,
      price: product.price,
      sellerWa: product.sellerWa,
      description: product.description,
      status: 'DANA AMAN DI REKBER ADMIN',
      date: new Date().toISOString().slice(0, 16).replace('T', ' '),
      codeUnik: codeUnik
    };

    const updatedInvoices = [newInvoice, ...invoices];
    setInvoices(updatedInvoices);
    localStorage.setItem('gamestore_invoices', JSON.stringify(updatedInvoices));

    const waText = 
      `Halo Admin Lapaku Game, saya ingin membeli akun game berikut melalui Rekber Escrow Aman:\n\n` +
      `*ID TRANSAKSI:* ${invoiceId}\n` +
      `*DETAIL PEMBELIAN:*\n` +
      `- *Game:* ${product.gameName}\n` +
      `- *Harga Akun:* ${formattedPrice}\n` +
      `- *Kode Unik Trf:* +Rp ${codeUnik}\n` +
      `- *Total Pembayaran:* Rp ${(product.price + codeUnik).toLocaleString('id-ID')}\n` +
      `- *No. WA Penjual:* ${product.sellerWa}\n` +
      `- *Detail Akun:* "${product.description.substring(0, 80)}..."\n\n` +
      `Tolong bantu diproses transaksi via Rekber/Escrow agar anti-penipuan. Saya siap melakukan transfer.`;

    const encodedText = encodeURIComponent(waText);
    const waUrl = `https://wa.me/${adminNo}?text=${encodedText}`;
    
    window.open(waUrl, '_blank');
    setActiveCheckoutProduct(null);
  };

  const gameTypes: { name: string }[] = [
    { name: 'All' },
    { name: 'Free Fire' },
    { name: 'Mobile Legends' },
    { name: 'CoC' },
    { name: 'Roblox' },
    { name: 'Minecraft' },
    { name: 'Genshin Impact' },
    { name: 'Valorant' },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 selection:bg-orange-500 selection:text-white flex flex-col justify-between">
      <div>
        <Navbar 
          currentPage={currentPage}
          setCurrentPage={setCurrentPage}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
        />

        {/* Home dynamic content view */}
        {currentPage === 'home' && (
          <>
            {/* Widescreen Promotion Banner Slot */}
            <section className="bg-slate-955 py-6 border-b border-slate-900/40">
              <div className="container mx-auto px-4 md:px-6">
                
                {/* Hidden Input File Trigger */}
                <input 
                  type="file"
                  ref={bannerFileRef}
                  onChange={handleBannerUpload}
                  accept="image/*"
                  className="hidden"
                />

                {!heroBanner ? (
                  <div 
                    onClick={() => bannerFileRef.current?.click()}
                    className="w-full bg-slate-900/60 border-2 border-dashed border-orange-500/20 hover:border-orange-500 hover:bg-orange-950/10 rounded-2xl p-8 md:p-14 flex flex-col items-center justify-center text-center gap-4 transition-all duration-300 cursor-pointer shadow-lg max-w-5xl mx-auto"
                    title="Klik untuk memilih foto dari galeri Anda"
                  >
                    <div className="w-14 h-14 rounded-full bg-orange-950/60 border border-orange-500/30 text-orange-500 flex items-center justify-center shadow-md animate-pulse">
                      <Plus className="w-7 h-7 stroke-[2.5]" />
                    </div>
                    <div>
                      <h3 className="text-base md:text-lg font-extrabold text-white font-sans">
                        Unggah Banner / Thumbnail Promosi Toko Anda
                      </h3>
                      <p className="text-xs md:text-sm text-slate-400 mt-1 max-w-md mx-auto leading-relaxed">
                        Klik di sini untuk membuka galeri foto peranti Anda. Banner terpilih akan dikunci sebagai cover utama marketplace Anda.
                      </p>
                    </div>
                    <span className="text-[10px] font-mono font-bold tracking-wider text-orange-400 uppercase bg-orange-950/40 px-3 py-1 rounded-full border border-orange-500/20 shadow-sm">
                      Rasio Widescreen Banner / Klik Untuk Upload
                    </span>
                  </div>
                ) : (
                  <div className="relative rounded-2xl overflow-hidden shadow-2xl max-w-5xl mx-auto border border-slate-800/80 aspect-[16/6] md:aspect-[21/7] group">
                    <img 
                      src={heroBanner} 
                      alt="Promosi Toko" 
                      className="w-full h-full object-cover select-none pointer-events-none"
                      referrerPolicy="no-referrer"
                    />
                    
                    {/* Visual Indicator of Locked State */}
                    <div className="absolute top-4 left-4 bg-slate-950/90 backdrop-blur-md px-3 py-1.5 rounded-full text-[10px] font-mono tracking-wider font-extrabold text-emerald-400 border border-emerald-900/30 flex items-center gap-1.5 shadow-md">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      BANNER PENJUALAN AKTIF
                    </div>

                    <button 
                      onClick={handleResetBanner}
                      className="absolute top-4 right-4 bg-red-600 hover:bg-red-500 text-white px-3 py-1.5 rounded-xl text-xs font-bold transition-all shadow-md flex items-center gap-1 cursor-pointer opacity-0 group-hover:opacity-100 focus:opacity-100 duration-200"
                      title="Ganti atau Reset Banner ke State Kosong"
                    >
                      <X className="w-3.5 h-3.5" />
                      Reset
                    </button>

                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/95 via-slate-950/60 to-transparent p-4 md:p-6 text-left flex flex-col justify-end">
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-orange-500 text-[10px] font-bold text-white uppercase w-fit mb-1.5 shadow-md">
                        Layanan Terpercaya 24 Jam
                      </span>
                      <h4 className="text-lg md:text-2xl font-extrabold text-white tracking-tight drop-shadow-sm leading-tight uppercase">
                        Promosi Store & Jual Beli Game Terbesar
                      </h4>
                      <p className="text-[10px] md:text-xs text-slate-300 max-w-xl truncate font-sans font-medium mt-0.5">
                        Sistem Rekber/Escrow otomatis melindungi Anda dari penipuan jual-beli akun game.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </section>

            {/* Game Listing Section */}
            <main className="container mx-auto px-4 md:px-6 py-12 animate-in fade-in duration-200" id="katalog">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10 pb-6 border-b border-slate-900">
                <div>
                  <h3 className="text-lg md:text-xl font-display font-extrabold text-white flex items-center gap-2">
                    <Grid className="w-5 h-5 text-orange-500" />
                    Daftar Akun Game Tersedia
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Gunakan filter di bawah untuk mempermudah pencarian game favorit Anda.
                  </p>
                </div>

                {/* Live Search Bar */}
                <div className="relative max-w-xs w-full">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500">
                    <Search className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    placeholder="Cari kata kunci..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 px-3.5 py-2 pl-10 rounded-xl text-xs sm:text-sm text-slate-100 focus:outline-none focus:border-orange-500 transition-colors placeholder:text-slate-550 shadow-inner"
                  />
                </div>
              </div>

              {/* Quick Filters */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-4 mb-8 -mx-4 px-4 scrollbar-none">
                {gameTypes.map((g) => (
                  <button
                    key={g.name}
                    onClick={() => setSelectedGame(g.name)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all border flex items-center justify-center cursor-pointer ${
                      selectedGame === g.name
                        ? 'bg-orange-500 text-white border-orange-500 shadow-lg shadow-orange-500/15'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-orange-500/30 hover:text-white shadow-md'
                    }`}
                  >
                    <span>{g.name}</span>
                  </button>
                ))}
              </div>

              {/* Catalog grid */}
              {loading ? (
                <div className="py-20 flex flex-col items-center justify-center gap-4 text-center">
                  <div className="w-10 h-10 border-4 border-orange-500 border-t-transparent rounded-full animate-spin" />
                  <p className="text-slate-450 text-xs font-mono">Memuat database akun game...</p>
                </div>
              ) : filteredProducts.length === 0 ? (
                <div className="py-12 px-6 bg-slate-900 border border-slate-800 rounded-3xl max-w-3xl mx-auto space-y-8 shadow-2xl">
                  <div className="text-center space-y-3">
                    <div className="w-12 h-12 bg-orange-950/40 border border-orange-500/20 rounded-2xl flex items-center justify-center mx-auto text-orange-400">
                      <Grid className="w-6 h-6" />
                    </div>
                    <h4 className="text-xl font-display font-bold text-white">Belum Ada Akun Game yang Dijual</h4>
                    <p className="text-slate-400 text-sm max-w-md mx-auto leading-relaxed">
                      Marketplace baru saja dibuka secara resmi. Jadilah penjual pertama yang mendaftarkan akun game Anda dan dapatkan eksposur langsung ke calon pembeli!
                    </p>
                  </div>

                  {/* Step by step seller onboarding */}
                  <div className="border-t border-slate-800 pt-6">
                    <h5 className="text-xs uppercase font-mono tracking-wider font-extrabold text-orange-500 mb-4 text-center">
                      Panduan Menjual Akun Game Anda
                    </h5>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-left">
                      <div className="bg-slate-950 border border-slate-850 p-4 rounded-xl">
                        <span className="font-mono text-orange-500 font-extrabold text-sm block mb-1">LANGKAH 1</span>
                        <h6 className="text-xs font-extrabold text-white mb-1">Unggah Iklan</h6>
                        <p className="text-[11px] text-slate-400 leading-relaxed">
                          Klik tombol tambah di sudut kanan bawah layar Anda untuk membuka formulir input kelengkapan produk.
                        </p>
                      </div>
                      <div className="bg-slate-950 border border-slate-850 p-4 rounded-xl">
                        <span className="font-mono text-orange-500 font-extrabold text-sm block mb-1">LANGKAH 2</span>
                        <h6 className="text-xs font-extrabold text-white mb-1">Isi Spesifikasi</h6>
                        <p className="text-[11px] text-slate-400 leading-relaxed">
                          Lengkapi nama game, harga target, deskripsi isi bundle akun, nomor WhatsApp Anda, serta unggah tangkapan layar bukti kepemilikan.
                        </p>
                      </div>
                      <div className="bg-slate-950 border border-slate-850 p-4 rounded-xl">
                        <span className="font-mono text-orange-500 font-extrabold text-sm block mb-1">LANGKAH 3</span>
                        <h6 className="text-xs font-extrabold text-white mb-1">Kirim Ke Admin</h6>
                        <p className="text-[11px] text-slate-400 leading-relaxed">
                          Tekan tombol kirim untuk mendaftarkan akun ke database sistem, serta membuka pesan WhatsApp konfirmasi otomatis kepada Admin.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-orange-950/20 border border-orange-500/10 p-4 rounded-xl text-center text-xs text-orange-400 font-sans leading-relaxed">
                    Sistem pendaftaran ini terproteksi keamanan ganda. Listing akan tayang secara langsung di halaman depan sesaat setelah Admin menyelesaikan pencocokan data akun dengan nomor WhatsApp Anda untuk menjamin integrasi data anti-fraud.
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                  {filteredProducts.map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      onOpenLightbox={handleOpenLightbox}
                      onBuy={handleRequestCheckout}
                    />
                  ))}
                </div>
              )}

              {/* Showcase Section / Educational rules panel */}
              <EscrowInfoSection />
            </main>
          </>
        )}

        {/* Dynamic subpages */}
        {currentPage === 'harga' && (
          <main className="container mx-auto px-4 md:px-6 py-12 max-w-4xl animate-in fade-in duration-200">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 space-y-6 shadow-2xl">
              <div className="border-b border-slate-800 pb-4">
                <span className="text-orange-500 font-mono font-extrabold tracking-wider text-xs uppercase px-2.5 py-1 rounded-full bg-orange-950/40 border border-orange-500/20">
                  Informasi Tarif Jasa
                </span>
                <h2 className="text-xl md:text-2xl font-sans font-extrabold tracking-tight text-white mt-2">
                  Daftar Harga Jasa Rekber
                </h2>
                <p className="text-xs text-slate-450 mt-1">
                  Kami membebankan biaya rekber paling ekonomis untuk menjamin keamanan transaksi Anda.
                </p>
              </div>

              <div className="border border-slate-800 rounded-xl overflow-hidden font-sans text-xs">
                <div className="grid grid-cols-2 bg-slate-950 border-b border-slate-800 p-3.5 font-bold text-slate-300 font-mono text-[10px]">
                  <span>RENTANG HARGA AKUN</span>
                  <span>KATEGORI TARIF REKBER</span>
                </div>
                <div className="divide-y divide-slate-800/80 font-medium text-sm">
                  <div className="grid grid-cols-2 p-3.5 hover:bg-slate-950 transition-colors">
                    <span>Rp 0 - Rp 100.000</span>
                    <span className="font-bold text-white font-mono">Rp 5.000 (Flat)</span>
                  </div>
                  <div className="grid grid-cols-2 p-3.5 hover:bg-slate-950 transition-colors">
                    <span>Rp 100.001 - Rp 250.000</span>
                    <span className="font-bold text-white font-mono">Rp 10.000 (Flat)</span>
                  </div>
                  <div className="grid grid-cols-2 p-3.5 hover:bg-slate-950 transition-colors">
                    <span>Rp 250.001 - Rp 500.000</span>
                    <span className="font-bold text-orange-500 font-mono">Rp 15.000 (Flat)</span>
                  </div>
                  <div className="grid grid-cols-2 p-3.5 hover:bg-slate-950 transition-colors">
                    <span>Rp 500.001 - Rp 1.000.000</span>
                    <span className="font-bold text-orange-500 font-mono">Rp 20.000 (Flat)</span>
                  </div>
                  <div className="grid grid-cols-2 p-3.5 hover:bg-slate-950 transition-colors">
                    <span>Luar Rp 1.000.000+</span>
                    <span className="font-bold text-orange-500 font-mono">Hanya 2%</span>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-orange-950/20 border border-orange-500/10 rounded-xl flex items-start gap-2.5 text-xs text-orange-400 font-medium leading-relaxed">
                <ShieldCheck className="w-5 h-5 text-orange-500 shrink-0 mt-0.5" />
                <span>
                  <strong>Siapa yang membayar biaya?</strong> Sesuai kesepakatan bersama, biaya rekber dapat ditanggung penuh oleh pembeli, dipotong dari hasil penjual, atau dibagi dua (50:50). Sampaikan ke Admin saat verifikasi WA dimulai!
                </span>
              </div>
            </div>
          </main>
        )}

        {currentPage === 'artikel' && (
          <main className="container mx-auto px-4 md:px-6 py-12 max-w-4xl animate-in fade-in duration-200">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 space-y-6 shadow-2xl">
              <div className="border-b border-slate-800 pb-4">
                <span className="text-orange-500 font-mono font-extrabold tracking-wider text-xs uppercase px-2.5 py-1 rounded-full bg-orange-950/40 border border-orange-500/20">
                  Tips Keamanan Pengguna
                </span>
                <h2 className="text-xl md:text-2xl font-sans font-extrabold tracking-tight text-white mt-2">
                  Artikel Edukasi Anti-Fraud
                </h2>
                <p className="text-xs text-slate-450 mt-1">
                  Ketahui modus operandi penipuan digital yang paling marak terjadi di game modern, serta panduan praktis melindunginya.
                </p>
              </div>

              <div className="space-y-4 font-sans">
                <details className="bg-slate-950 hover:bg-slate-950/80 transition-all border border-slate-800 rounded-xl p-4 cursor-pointer group">
                  <summary className="font-extrabold text-white text-sm flex items-center justify-between">
                    <span>Modus Penipuan Segitiga (Triangle Fraud)</span>
                    <span className="text-orange-500 font-bold group-open:rotate-180 transition-transform">▼</span>
                  </summary>
                  <div className="mt-2 text-xs md:text-sm text-slate-300 leading-relaxed space-y-1.5 pt-1.5 border-t border-slate-800 font-sans">
                    <p>Penipu berpura-pura menjadi Pembeli kepada Penjual asli, dan sekaligus penipu berpura-pura menjadi Penjual murah kepada Pembeli asli.</p>
                    <p className="text-red-400 font-bold">Cara menangkal:</p>
                    <p>Selalu buat grup chat WA resmi dengan Admin 6285872118540. Pastikan nomor e-wallet / bank transfer yang dituju hanya milik Admin resmi, bukan rekening orang lain.</p>
                  </div>
                </details>

                <details className="bg-slate-950 hover:bg-slate-950/80 transition-all border border-slate-800 rounded-xl p-4 cursor-pointer group">
                  <summary className="font-extrabold text-white text-sm flex items-center justify-between">
                    <span>5 Langkah Wajib Amankan Akun setelah Handover</span>
                    <span className="text-orange-500 font-bold group-open:rotate-180 transition-transform">▼</span>
                  </summary>
                  <div className="mt-2 text-xs md:text-sm text-slate-300 leading-relaxed space-y-1.5 pt-1.5 border-t border-slate-800 font-sans list-decimal list-inside">
                    <p>1. Segera ubah sandi login primer.</p>
                    <p>2. Ganti email pemulihan (Recovery Email) ke email pribadi Anda.</p>
                    <p>3. Nyalakan Autentikasi Dua Faktor (2FA) Google / Moonton.</p>
                    <p>4. Putuskan koneksi dari semua perangkat tidak dikenal (Log Out All Other Devices).</p>
                    <p>5. Kaitkan sisa slot sosial ke akun pribadimu (Facebook/VK/Google).</p>
                  </div>
                </details>

                <details className="bg-slate-950 hover:bg-slate-950/80 transition-all border border-slate-800 rounded-xl p-4 cursor-pointer group">
                  <summary className="font-extrabold text-white text-sm flex items-center justify-between">
                    <span>Mengapa Transaksi Direct (Direct Transfer) Sangat Berbahaya?</span>
                    <span className="text-orange-500 font-bold group-open:rotate-180 transition-transform">▼</span>
                  </summary>
                  <div className="mt-2 text-xs md:text-sm text-slate-300 leading-relaxed pt-1.5 border-t border-slate-800 font-sans">
                    Sembilan dari sepuluh transaksi direct-transfer di media sosial berakhir dengan pembeli diblokir setelah transfer. Sistem Escrow memegang dana Anda dengan aman hingga data akun lengkap Anda terima seutuhnya.
                  </div>
                </details>
              </div>
            </div>
          </main>
        )}

        {currentPage === 'edukasi' && (
          <main className="container mx-auto px-4 md:px-6 py-12 max-w-5xl animate-in fade-in duration-200">
            <EscrowInfoSection />
          </main>
        )}
      </div>

      {/* Floating Add Product Button */}
      {currentPage === 'home' && (
        <div className="fixed bottom-6 right-6 z-40">
          <button
            onClick={() => setShowAddModal(true)}
            id="add-product-btn"
            className="bg-orange-500 hover:bg-orange-600 text-white font-bold w-14 h-14 rounded-full shadow-2xl shadow-orange-500/20 flex items-center justify-center transition-all hover:scale-105 active:scale-95 cursor-pointer ring-4 ring-orange-500/10"
            title="Tambahkan Iklan Akun Baru"
          >
            <Plus className="w-7 h-7 stroke-[2.5]" />
          </button>
        </div>
      )}

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-10 text-slate-400 text-xs mt-12">
        <div className="container mx-auto px-4 md:px-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center md:text-left">
            <p className="text-white font-extrabold font-mono uppercase tracking-wider">
              GAMESTORE LAPAKU OFFICIAL
            </p>
            <p className="text-slate-400 font-medium">Sistem Rekber Resmi terintegrasi WhatsApp Admin: 085872118540</p>
          </div>
          <div className="flex items-center gap-1.5 bg-emerald-950/20 border border-emerald-900/30 rounded-lg px-3 py-1.5 text-[10px] text-emerald-400 font-extrabold shadow-sm">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>Escrow & Rekber Protection Active</span>
          </div>
          <p className="text-slate-500">© 2026 GameStore. Seluruh Hak Cipta Dilindungi.</p>
        </div>
      </footer>

      {/* SHOW LIGHTBOX MODAL */}
      {activeLightboxProduct && (
        <LightboxModal
          product={activeLightboxProduct}
          currentIndex={lightboxIndex}
          onClose={handleCloseLightbox}
          onPrev={handlePrevPhoto}
          onNext={handleNextPhoto}
          onChangeIndex={handleChangeIndex}
        />
      )}

      {/* SHOW ADD PRODUCT FORM MODAL */}
      {showAddModal && (
        <AddProductForm
          onClose={() => setShowAddModal(false)}
          onAddProduct={handleAddProduct}
        />
      )}

      {/* CONFIRM PURCHASE MODAL */}
      {activeCheckoutProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-800 shadow-2xl rounded-2xl w-full max-w-md overflow-hidden p-6 relative text-slate-100">
            <button 
              onClick={() => setActiveCheckoutProduct(null)} 
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center space-y-4">
              <div className="w-12 h-12 rounded-full bg-emerald-950/30 border border-emerald-905 text-emerald-450 flex items-center justify-center mx-auto shadow-sm">
                <ShieldCheck className="w-6 h-6" />
              </div>
              
              <div className="space-y-1">
                <h4 className="text-lg font-extrabold text-white font-sans">Konfirmasi Transaksi Rekber</h4>
                <p className="text-xs text-slate-400 font-sans">
                  Semua transaksi diproses aman oleh Rekber Admin untuk mencegah penipuan.
                </p>
              </div>

              {/* Account summary display card */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-left space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Game:</span>
                  <span className="font-extrabold text-white font-mono uppercase">{activeCheckoutProduct.gameName}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Harga Akun:</span>
                  <span className="font-extrabold text-orange-500 font-mono">
                    {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(activeCheckoutProduct.price)}
                  </span>
                </div>
                <div className="border-t border-slate-800/80 pt-2 text-[11px] text-slate-400 leading-relaxed italic font-sans animate-pulse">
                  "{activeCheckoutProduct.description.substring(0, 90)}..."
                </div>
              </div>

              {/* Notice explaining physical safety flow */}
              <div className="bg-amber-955/20 border border-amber-900/30 p-3 rounded-xl flex items-start gap-2 text-[10px] text-amber-300 text-left leading-relaxed font-sans">
                <AlertTriangle className="w-4 h-4 shrink-0 text-amber-500 mt-0.5" />
                <span>
                  <strong>Informasi Keamanan:</strong> Jangan melakukan transaksi atau transfer ke penjual langsung di luar grup obrolan resmi Admin! Hanya transfer ke rekening resmi yang diberikan Admin saat obrolan WhatsApp berlangsung.
                </span>
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  onClick={() => setActiveCheckoutProduct(null)}
                  className="flex-1 bg-slate-950 border border-slate-800 hover:bg-slate-850 text-slate-300 py-2.5 rounded-xl text-xs font-bold cursor-pointer transition-all"
                >
                  Batal
                </button>
                <button
                  onClick={() => handleConfirmPurchase(activeCheckoutProduct)}
                  className="flex-1 bg-orange-500 hover:bg-orange-600 text-white py-2.5 rounded-xl text-xs font-extrabold shadow-lg shadow-orange-500/15 flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                >
                  <MessageSquare className="w-3.5 h-3.5 fill-white/10" />
                  Hubungi Admin WA
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
