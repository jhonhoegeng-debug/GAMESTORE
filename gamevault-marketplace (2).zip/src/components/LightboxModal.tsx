import { X, ChevronLeft, ChevronRight, Download } from 'lucide-react';
import { Product } from '../types';

interface LightboxModalProps {
  product: Product;
  currentIndex: number;
  onClose: () => void;
  onPrev: () => void;
  onNext: () => void;
  onChangeIndex: (index: number) => void;
}

export default function LightboxModal({
  product,
  currentIndex,
  onClose,
  onPrev,
  onNext,
  onChangeIndex,
}: LightboxModalProps) {
  const photos = product.photos || [];
  const currentPhoto = photos[currentIndex] || '';
  const totalPhotos = photos.length;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/95 backdrop-blur-md p-4 transition-all"
      onClick={onClose}
    >
      {/* Lightbox Content Container */}
      <div
        className="relative max-w-5xl w-full flex flex-col items-center justify-center"
        onClick={(e) => e.stopPropagation()} // Prevent close on clicking image content
      >
        {/* Header bar within Lightbox */}
        <div className="absolute -top-12 left-0 right-0 flex items-center justify-between text-slate-300 px-1 z-50">
          <div className="flex flex-col">
            <span className="text-xs uppercase font-mono tracking-wider text-emerald-400 font-bold">
              Detail Akun - {product.gameName}
            </span>
            <span className="text-sm font-semibold truncate max-w-xs md:max-w-md text-white">
              {product.description.substring(0, 50)}...
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-lg text-xs font-mono font-bold text-white">
              {currentIndex + 1} / {totalPhotos}
            </span>
            <button
              onClick={onClose}
              id="close-lightbox"
              className="bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white p-2 rounded-lg border border-slate-800 transition-colors cursor-pointer"
              title="Close (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Dynamic Image Wrapper */}
        <div className="relative w-full aspect-video md:max-h-[75vh] flex items-center justify-center bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
          <img
            src={currentPhoto}
            alt={`Detail item ${currentIndex + 1}`}
            referrerPolicy="no-referrer"
            className="max-w-full max-h-[75vh] object-contain select-none"
            onError={(e) => {
              e.currentTarget.src = 'https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=800&auto=format&fit=crop';
            }}
          />

          {/* Navigation Controls: Prev & Next (ONLY if more than 1 photo) */}
          {totalPhotos > 1 && (
            <>
              {/* Prev Button */}
              <button
                onClick={onPrev}
                id="prev-photo"
                className="absolute left-4 top-1/2 -translate-y-1/2 bg-slate-900/80 hover:bg-emerald-500 text-white hover:text-slate-950 p-2.5 md:p-3.5 rounded-full border border-slate-800 transition-all flex items-center justify-center shadow-lg cursor-pointer"
                aria-label="Previous photo"
              >
                <ChevronLeft className="w-6 h-6 stroke-[2.5]" />
              </button>

              {/* Next Button */}
              <button
                onClick={onNext}
                id="next-photo"
                className="absolute right-4 top-1/2 -translate-y-1/2 bg-slate-900/80 hover:bg-emerald-500 text-white hover:text-slate-950 p-2.5 md:p-3.5 rounded-full border border-slate-800 transition-all flex items-center justify-center shadow-lg cursor-pointer"
                aria-label="Next photo"
              >
                <ChevronRight className="w-6 h-6 stroke-[2.5]" />
              </button>
            </>
          )}

          {/* Helper caption overlays */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-slate-950/80 backdrop-blur-sm border border-slate-800 px-3.5 py-1.5 rounded-full hidden md:flex items-center gap-2">
            <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider">
              Gunakan panah &lt; &gt; untuk melihat detail foto lainnya
            </span>
          </div>
        </div>

        {/* Thumbnail Selectors below Image */}
        {totalPhotos > 1 && (
          <div className="flex items-center gap-2.5 mt-4 overflow-x-auto max-w-full py-2 px-1">
            {photos.map((photo, index) => (
              <button
                key={index}
                onClick={() => onChangeIndex(index)}
                className={`relative w-14 h-10 rounded-md overflow-hidden bg-slate-900 border transition-all ${
                  currentIndex === index
                    ? 'border-emerald-400 ring-2 ring-emerald-500/25 scale-105'
                    : 'border-slate-800 opacity-60 hover:opacity-100'
                }`}
              >
                <img
                  src={photo}
                  alt={`Thumbnail ${index + 1}`}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
