import { Product } from '../types';
import { MessageSquare, Image as ImageIcon, ShieldCheck, Tag } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onOpenLightbox: (product: Product, index: number) => void;
  onBuy: (product: Product) => void;
}

export default function ProductCard({ product, onOpenLightbox, onBuy }: ProductCardProps) {
  // Helper to format currency to Rupiah style or high-quality clean layout
  const formatRupiah = (num: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(num);
  };

  const getGameBadgeColor = (game: string) => {
    switch (game) {
      case 'Free Fire':
        return 'from-orange-500 to-red-600 border-orange-500/35 text-white';
      case 'Mobile Legends':
        return 'from-blue-600 to-indigo-700 border-blue-500/35 text-white';
      case 'CoC':
        return 'from-amber-600 to-amber-700 border-amber-500/35 text-amber-100';
      case 'Roblox':
        return 'from-slate-600 to-slate-800 border-slate-500/35 text-slate-100';
      case 'Minecraft':
        return 'from-green-600 to-emerald-700 border-green-500/35 text-white';
      case 'Genshin Impact':
        return 'from-purple-600 to-pink-700 border-purple-500/35 text-white';
      case 'Valorant':
        return 'from-rose-600 to-rose-800 border-rose-500/35 text-white';
      default:
        return 'from-slate-600 to-slate-700 border-slate-500/35 text-white';
    }
  };

  const mainPhoto = product.photos[0] || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop&q=60';
  const photoCount = product.photos.length;

  return (
    <article className="group bg-slate-900 border border-slate-800/80 hover:border-orange-500/50 rounded-2xl overflow-hidden transition-all duration-300 hover:shadow-2xl hover:shadow-orange-500/5 flex flex-col h-full shadow-md">
      {/* Product Image Section */}
      <div className="relative aspect-video w-full overflow-hidden bg-slate-950">
        <img
          src={mainPhoto}
          alt={`Akun ${product.gameName}`}
          referrerPolicy="no-referrer"
          onClick={() => onOpenLightbox(product, 0)}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 cursor-zoom-in"
          onError={(e) => {
            // fallback image if broken link
            e.currentTarget.src = 'https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=800&auto=format&fit=crop';
          }}
        />
        
        {/* Game Name Tag Overlay */}
        <div className="absolute top-3 left-3 flex items-center gap-1.5 shadow-md">
          <span className={`bg-gradient-to-r ${getGameBadgeColor(product.gameName)} px-2.5 py-1 text-[11px] font-mono tracking-wider font-extrabold rounded-lg uppercase border border-white/10 shadow-sm`}>
            {product.gameName}
          </span>
        </div>

        {/* Dynamic Image Count Badge */}
        {photoCount > 1 && (
          <button 
            onClick={() => onOpenLightbox(product, 0)}
            className="absolute bottom-3 right-3 bg-slate-900/90 backdrop-blur-sm border border-slate-800 text-slate-200 text-xs px-2.5 py-1 rounded-lg flex items-center gap-1.5 hover:text-white hover:bg-slate-850 transition-colors cursor-pointer shadow-sm"
          >
            <ImageIcon className="w-3.5 h-3.5 text-orange-500" />
            <span className="font-bold">{photoCount} Foto</span>
          </button>
        )}
      </div>

      {/* Content Section */}
      <div className="p-5 flex flex-col flex-grow justify-between">
        <div className="space-y-2">
          {/* Headline / Price info */}
          <div className="flex items-baseline justify-between gap-2">
            <span className="text-xl font-bold font-mono text-orange-500 tracking-tight">
              {formatRupiah(product.price)}
            </span>
            <span className="text-[10px] font-mono text-emerald-500 flex items-center gap-1 font-bold">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 fill-emerald-950/20" /> REKBER AKTIF
            </span>
          </div>

          {/* Description */}
          <p className="text-slate-300 text-sm leading-relaxed line-clamp-3 min-h-[60px] font-sans">
            {product.description}
          </p>
        </div>

        {/* Footer info & Buy Button */}
        <div className="mt-5 pt-4 border-t border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="flex items-center gap-1 font-medium">
              <Tag className="w-3.5 h-3.5 text-slate-500" /> Akun Game
            </span>
            <span className="font-mono bg-slate-950 border border-slate-800/80 px-2.5 py-1 rounded font-bold text-[10px] text-slate-400">
              WA Penjual: {product.sellerWa.substring(0, 4)}***{product.sellerWa.slice(-3)}
            </span>
          </div>

          <button
            onClick={() => onBuy(product)}
            className="w-full bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-extrabold py-2.5 px-4 rounded-xl text-xs md:text-sm tracking-wide transition-all shadow-lg shadow-orange-500/10 active:scale-[0.98] flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <MessageSquare className="w-4 h-4 text-white fill-white/10" />
            Hubungi Admin & Beli Akun
          </button>
        </div>
      </div>
    </article>
  );
}
