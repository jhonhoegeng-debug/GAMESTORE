import { Shield, Flame, Search, BookOpen, CreditCard } from 'lucide-react';

interface NavbarProps {
  currentPage: string;
  setCurrentPage: (page: string) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
}

export default function Navbar({ currentPage, setCurrentPage, searchQuery, setSearchQuery }: NavbarProps) {
  const handleSearchChange = (val: string) => {
    setSearchQuery(val);
    if (currentPage !== 'home') {
      setCurrentPage('home');
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800 bg-slate-950">
      {/* Upper Main-Navbar Tier */}
      <div className="border-b border-slate-900 bg-slate-950 shadow-lg">
        <div className="container mx-auto px-4 md:px-6 h-16 flex items-center justify-between gap-4">
          
          {/* Logo Brand / Icon */}
          <div 
            className="flex items-center gap-2 shrink-0 cursor-pointer" 
            onClick={() => {
              setSearchQuery('');
              setCurrentPage('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-orange-500 to-red-600 flex items-center justify-center shadow-lg shadow-orange-500/20">
              <Flame className="w-6 h-6 text-white fill-white" />
            </div>
            <div>
              <span className="text-xl font-black font-sans tracking-tight text-white uppercase block leading-none">
                GAMESTORE
              </span>
              <span className="text-[8.5px] font-mono tracking-widest text-slate-450 block mt-1 uppercase font-bold">
                MARKETPLACE RESMI
              </span>
            </div>
          </div>

          {/* Interactive Wide Search Box (Exactly like Screenshot) */}
          <div className="flex-grow max-w-xl relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-450 pointer-events-none">
              <Search className="w-4 h-4 stroke-[2.5]" />
            </span>
            <input
              type="text"
              placeholder="Cari game favorit Anda (Free Fire, Mobile Legends, CoC...)"
              value={searchQuery}
              onChange={(e) => handleSearchChange(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 pl-10 pr-4 py-2.5 rounded-full text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 focus:bg-slate-900 transition-all shadow-inner"
            />
          </div>

          {/* Optional right spacer for balance or search */}
          <div className="w-4 hidden md:block"></div>

        </div>
      </div>

      {/* Lower Sub-Navbar Tier */}
      <div className="bg-slate-950/70 backdrop-blur-md border-b border-slate-900">
        <div className="container mx-auto px-4 md:px-6 flex items-center justify-start gap-1 sm:gap-4 overflow-x-auto h-11 scrollbar-none">
          <button
            onClick={() => {
              setSearchQuery('');
              setCurrentPage('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`px-3 py-1.5 text-xs font-bold flex items-center gap-1 shrink-0 cursor-pointer transition-all border-b-2 ${
              currentPage === 'home'
                ? 'text-orange-500 border-orange-500 font-extrabold'
                : 'text-slate-400 border-transparent hover:text-orange-500'
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            Home
          </button>

          <button
            onClick={() => {
              setCurrentPage('harga');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`px-3 py-1.5 text-xs font-semibold transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer transition-all border-b-2 ${
              currentPage === 'harga'
                ? 'text-orange-500 border-orange-500 font-extrabold'
                : 'text-slate-400 border-transparent hover:text-orange-500'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5" />
            Daftar Harga Rekber
          </button>

          <button
            onClick={() => {
              setCurrentPage('artikel');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`px-3 py-1.5 text-xs font-semibold transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer transition-all border-b-2 ${
              currentPage === 'artikel'
                ? 'text-orange-500 border-orange-500 font-extrabold'
                : 'text-slate-400 border-transparent hover:text-orange-500'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            Artikel Rekber
          </button>

          <button
            onClick={() => {
              setCurrentPage('edukasi');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`px-3 py-1.5 text-xs font-semibold transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer transition-all border-b-2 ${
              currentPage === 'edukasi'
                ? 'text-orange-500 border-orange-500 font-extrabold'
                : 'text-slate-400 border-transparent hover:text-orange-500'
            }`}
          >
            <Shield className="w-3.5 h-3.5 text-orange-500" />
            Edukasi Keamanan
          </button>
        </div>
      </div>
    </header>
  );
}
