import { useState } from 'react';
import { ShieldAlert, CreditCard, CheckCircle2, KeyRound } from 'lucide-react';

export default function EscrowInfoSection() {
  const [activeTab, setActiveTab] = useState<'flow' | 'fee'>('flow');

  return (
    <div id="escrow-rule-section" className="bg-slate-900 border border-slate-800/80 rounded-2xl p-6 md:p-8 text-slate-100 shadow-xl overflow-hidden my-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-6 border-b border-slate-800 font-sans">
        <div>
          <span className="text-orange-500 font-mono font-extrabold tracking-wider text-xs uppercase px-2.5 py-1 rounded-full bg-orange-950/40 border border-orange-500/20">
            Sistem Keamanan & Edukasi Rekber
          </span>
          <h2 className="text-xl md:text-2xl font-sans font-extrabold tracking-tight text-white mt-2">
            Panduan Rekber Escrow Resmi
          </h2>
        </div>
        
        {/* Tab Controls */}
        <div className="flex p-1 bg-slate-950 rounded-lg border border-slate-800 self-start md:self-center">
          <button
            onClick={() => setActiveTab('flow')}
            className={`px-4 py-1.5 text-xs font-bold rounded-md transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'flow'
                ? 'bg-orange-500 text-white shadow-md shadow-orange-500/10'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            Alur Escrow (Rekber)
          </button>
          <button
            onClick={() => setActiveTab('fee')}
            className={`px-4 py-1.5 text-xs font-bold rounded-md transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'fee'
                ? 'bg-orange-500 text-white shadow-md shadow-orange-500/10'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5" />
            Perhitungan Biaya
          </button>
        </div>
      </div>

      {activeTab === 'flow' && (
        <div>
          <p className="text-slate-300 text-sm mb-6 leading-relaxed max-w-3xl font-sans">
            Sistem escrow (rekening bersama) menjaga keadilan transaksi antara pembeli dan penjual. 
            Uang ditahan sementara oleh pihak Admin Marketplace selaku jembatan terpercaya agar terhindar dari modus kabur atau penyerahan akun bodong.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 relative">
            <div className="absolute top-[28px] left-[5%] right-[5%] h-0.5 bg-slate-800 hidden md:block z-0" />
            
            <div className="bg-slate-950 border border-slate-800/85 p-4 rounded-xl relative z-10 hover:border-orange-500/30 transition-colors shadow-sm">
              <div className="w-8 h-8 rounded-full bg-orange-500 text-white flex items-center justify-center font-mono font-extrabold text-xs mb-3 shadow-md shadow-orange-500/15">
                1
              </div>
              <h4 className="font-extrabold text-sm text-white mb-1 flex items-center gap-1 font-sans">
                Sinyal Keinginan Beli
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed font-sans">
                Pembeli klik tombol beli dan dialihkan ke WhatsApp Admin seharga produk dengan template rincian akun otomatis.
              </p>
            </div>

            <div className="bg-slate-950 border border-slate-800/85 p-4 rounded-xl relative z-10 hover:border-orange-500/30 transition-colors shadow-sm">
              <div className="w-8 h-8 rounded-full bg-orange-500 text-white flex items-center justify-center font-mono font-extrabold text-xs mb-3 shadow-md shadow-orange-500/15">
                2
              </div>
              <h4 className="font-extrabold text-sm text-white mb-1 flex items-center gap-1 font-sans">
                Amankan Dana (Escrow)
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed font-sans">
                Pembeli mentransfer dana ke rekening Admin resmi. Admin mematikan status listing di web dan mengonfirmasi dana masuk aman.
              </p>
            </div>

            <div className="bg-slate-950 border border-slate-800/85 p-4 rounded-xl relative z-10 hover:border-orange-500/30 transition-colors shadow-sm">
              <div className="w-8 h-8 rounded-full bg-orange-500 text-white flex items-center justify-center font-mono font-extrabold text-xs mb-3 shadow-md shadow-orange-500/15">
                3
              </div>
              <h4 className="font-extrabold text-sm text-white mb-1 flex items-center gap-1 font-sans">
                Migrasi Akun
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed font-sans">
                Penjual memberikan kredensial akun kepada Admin. Admin membantu/memantau pembeli mengamankan dan mengubah verifikasi akun.
              </p>
            </div>

            <div className="bg-slate-950 border border-slate-800/85 p-4 rounded-xl relative z-10 hover:border-orange-500/30 transition-colors shadow-sm">
              <div className="w-8 h-8 rounded-full bg-orange-500 text-white flex items-center justify-center font-mono font-extrabold text-xs mb-3 shadow-md shadow-orange-500/15">
                4
              </div>
              <h4 className="font-extrabold text-sm text-white mb-1 flex items-center gap-1 font-sans">
                Pencairan Dana (Payout)
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed font-sans">
                Setelah pembeli menyatakan akun aman, Admin mencairkan dana ke Penjual setelah dikurangi biaya admin.
              </p>
            </div>
          </div>

          <div className="mt-8 bg-emerald-950/15 border border-emerald-900/30 p-4 rounded-xl flex items-start gap-3 shadow-sm">
            <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
            <div className="text-xs text-slate-300 font-sans leading-relaxed">
              <strong className="text-emerald-400 block mb-1 font-bold">Keunggulan Sistem Escrow Terintegrasi:</strong>
              Mereduksi 100% penipuan segitiga, pemalsuan bukti transfer, atau klaim sepihak. Admin melakukan verifikasi ganda via chat WhatsApp dan verifikasi langsung kepemilikan akun sebelum dana dicairkan.
            </div>
          </div>
        </div>
      )}

      {activeTab === 'fee' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 font-sans">
          <div className="md:col-span-2 space-y-4">
            <h4 className="text-lg font-bold text-white mb-2">Simulasi Keuntungan dan Skema Biaya Rekber</h4>
            <p className="text-slate-300 text-sm leading-relaxed font-sans">
              Biaya administrasi (fee rekber) dapat dibebankan ke pembeli, penjual, atau dibagi rata. 
              Disarankan menggunakan skema potongan dari penjual atau flat fee tambahan yang ditanggung pembeli.
            </p>

            <div className="space-y-3">
              <div className="bg-slate-950 border border-slate-850 p-4 rounded-xl">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm font-bold text-slate-200">Skema Potongan Penjual</span>
                  <span className="text-xs font-mono font-bold text-orange-500 bg-orange-950/40 px-2 py-0.5 rounded border border-orange-500/10">Default (3% - 5%)</span>
                </div>
                <p className="text-xs text-slate-450 font-sans">
                  Harga yang dipajang adalah bersih atau kotor. Biaya admin dipotong langsung sebelum dana dikirim ke penjual asli.
                </p>
                <div className="mt-2 text-xs bg-orange-950/30 text-orange-400 border border-orange-500/20 px-2.5 py-1.5 rounded-lg font-mono font-bold">
                  Dana yang Diterima Penjual = Harga Tertera - Fee Admin (Min 5.000 atau 5% Harga)
                </div>
              </div>

              <div className="bg-slate-950 border border-slate-850 p-4 rounded-xl">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm font-bold text-slate-200">Skema Biaya Pembeli</span>
                  <span className="text-xs font-mono font-bold text-indigo-400 bg-indigo-950/40 px-2 py-0.5 rounded border border-indigo-550/20 animate-pulse">Alternatif</span>
                </div>
                <p className="text-xs text-slate-450 font-sans">
                  Pembeli membayar harga barang + Biaya Flat Rekber (biasanya Rp5.000 s/d Rp15.000 tergantung nominal harga).
                </p>
              </div>
            </div>
          </div>

          <div className="bg-slate-950 border border-slate-850 p-5 rounded-xl flex flex-col justify-between shadow-sm">
            <div>
              <div className="flex items-center gap-1.5 mb-2">
                <KeyRound className="w-4 h-4 text-orange-500" />
                <span className="text-xs font-mono tracking-wider uppercase text-slate-400 font-bold">Kalkulator Fee</span>
              </div>
              <h5 className="text-sm font-bold text-white mb-4">Contoh Skenario Akun Rp 150.000</h5>
              
              <ul className="space-y-3.5 text-xs text-slate-300">
                <li className="flex justify-between font-sans">
                  <span className="text-slate-400">Harga Jual Akun:</span>
                  <span className="font-mono text-white font-bold">Rp 150.000</span>
                </li>
                <li className="flex justify-between pb-2 border-b border-slate-800 font-sans">
                  <span className="text-slate-400">Admin Fee (5%):</span>
                  <span className="font-mono text-red-400 font-bold">- Rp 7.500</span>
                </li>
                <li className="flex justify-between pt-1 font-sans">
                  <span className="text-slate-305 font-bold">Iterasi Payout Penjual:</span>
                  <span className="font-mono text-emerald-400 font-extrabold">Rp 142.500</span>
                </li>
                <li className="flex justify-between font-sans">
                  <span className="text-slate-305 font-bold">Keuntungan Platform:</span>
                  <span className="font-mono text-orange-400 font-extrabold">Rp 7.500</span>
                </li>
              </ul>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-800 text-[10px] text-slate-400 leading-relaxed font-sans">
              *Penetapan nominal transfer wajib disertai detail 3 digit kode unik (misal: Rp 150.720) bagi pembeli untuk mempermudah deteksi pembayaran otomatis di sisi Admin.
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
