import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

interface Product {
  id: string;
  gameName: string;
  description: string;
  price: number;
  sellerWa: string;
  photos: string[];
  createdAt: string;
}

// Initial list is empty as requested since no accounts have been published for sale yet
let products: Product[] = [];

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware
  app.use(express.json({ limit: "15mb" }));
  app.use(express.urlencoded({ extended: true, limit: "15mb" }));

  // 1. GET ALL PRODUCTS
  app.get("/api/products", (req, res) => {
    res.json(products);
  });

  // 2. CREATE NEW PRODUCT (AND RETURN SUCCESS FOR REDIRECT)
  app.post("/api/products", (req, res) => {
    const { gameName, description, price, sellerWa, photos } = req.body;

    if (!gameName || !description || !price || !sellerWa || !photos || !Array.isArray(photos)) {
      return res.status(400).json({ error: "Kolom produk tidak lengkap!" });
    }

    const newProduct: Product = {
      id: `prod-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      gameName,
      description,
      price: Number(price),
      sellerWa,
      photos,
      createdAt: new Date().toISOString()
    };

    // Prepend to show newest listings first
    products.unshift(newProduct);

    res.status(201).json({
      success: true,
      message: "Sukses mendaftarkan iklan produk akun game!",
      product: newProduct
    });
  });

  // 3. API HEALTHCHECK & DIAGNOSTICS FOR ADMIN WHATSAPP REDIRECT BUILDER
  app.get("/api/whatsapp-generator", (req, res) => {
    const { action, sellerNo, game, price, description } = req.query;
    const adminNo = "6285872118540"; // No Admin resmi

    if (action === "pendaftaran") {
      const text = `Halo Admin Lapaku Game, saya ingin mendaftarkan produk akun game baru agar diverifikasi.\n\n- Game: ${game}\n- Harga: Rp ${price}\n- WA Penjual: ${sellerNo}\n\nMohon diproses untuk tayang di Beranda.`;
      const url = `https://wa.me/${adminNo}?text=${encodeURIComponent(text)}`;
      return res.json({ url });
    } else if (action === "pembelian") {
      const text = `Halo Admin, saya ingin membeli akun ${game} dengan detail "${description}" seharga Rp ${price}. Tolong proses via Rekber/Escrow agar anti-penipuan.`;
      const url = `https://wa.me/${adminNo}?text=${encodeURIComponent(text)}`;
      return res.json({ url });
    }

    res.status(400).json({ error: "Action tidak dikenali" });
  });

  // Vite integration
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Lapaku Game Backend] Express running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Startup error:", err);
});
